# Experimental Chapter-Sample Protocol

Protocol version: `1.0.0`

Use this protocol only when the user explicitly requests a chapter sample. It is
an additive experimental mode. It does not relax or silently replace the
full-content contract in `scoring-protocol.md`; a normal invocation still reads
every chapter.

## Scope and interpretation

- Set `evaluation_mode` and `evaluation_scope.mode` to `chapter_sample`.
- Label every score **Experimental four-chapter sample score** and interpret it
  only as an exploratory estimate of observable design in selected chapters.
- Never call the result a full-book evaluation, certification, audit finding,
  or package-wide conclusion. Unsampled content may materially change every
  score, rank, gate, and recommendation.
- Keep two blind raters, one separate adjudicator per book, deterministic
  arithmetic, and post-adjudication calibration.
- Give both blind raters and the adjudicator the identical sampled package. A
  worker must not open the original source path recorded in sample metadata,
  any unsampled chapter, or any full-book output.
- Keep external accuracy `not_assessed`; measured reader outcomes remain out of
  scope.

## Canonical deterministic selection

`sample_chapters.py` is the executable selection contract. For every canonical
book with `n` chapters it chooses `k = min(4, n)` as follows:

1. Compute the original package's byte-level SHA-256 digest.
2. Derive the per-book seed:

   ```text
   SHA-256(UTF-8(public_seed + NUL + full_source_sha256 + NUL + book_id))
   ```

3. Canonically encode each complete chapter object as sorted, compact JSON and
   compute its SHA-256 chapter fingerprint.
4. Compute each selection rank:

   ```text
   SHA-256(UTF-8(per_book_seed_sha256 + NUL + chapter_fingerprint_sha256))
   ```

5. Choose the four lowest ranks, or all chapters when fewer than four exist,
   using the documented deterministic tie-breakers. Restore original source
   order in the sampled view.

The canonical algorithm name is `sha256-lowest-rank-v1`; do not shorten or
rename it. Record the public seed, complete algorithm object, original source
hash, sampled-package hash, per-book seed, and every selected chapter's
original zero-based index, one-based position, selection order, id, number,
title, fingerprint, and rank in JSON and CSV manifests.

Create sample-only package views inside the run directory. Preserve book
metadata and the complete selected chapter objects, omit unselected chapters,
and add `_chapterflowEvaluationSample` metadata. Never modify
`book-packages/`.

After discovery and sampling, run `prepare_sample_jobs.py`. It copies the JSON
and CSV selection manifests into `data/`, hashes the copied JSON bytes, checks
the sampled set against every canonical discovery row, writes one hashed exact
`evaluation_scope` snapshot per book for validator input, and replaces only the
new run's job ledgers with sample-mode jobs. Use a fresh discovered run; never
convert a run after any rating output exists.

## Blind-rater contract

Each worker receives only its sampled package, the rubric, this protocol,
`book-evaluation-sample.schema.json`, its immutable sample identity, and its
unique output path. It must:

1. Verify the sampled-package and selection-manifest hashes.
2. Read every selected chapter and every reader-facing component in those
   chapters in full. Do not open the original source path carried as metadata.
3. Copy the package's sample identity into `evaluation_scope`, including the
   exact selection algorithm object and selected-chapter records.
4. Set expected and read chapter counts to the selected sample. For each
   `chapter_evidence` item, copy `original_chapter_index`,
   `original_chapter_position`, and `selection_order`; set the ordinary
   `chapter_index` to the original one-based position and preserve the exact
   selected id and title.
5. Rate all 36 subcriteria as sample-based estimates using selected evidence
   only. Absence in unseen chapters earns neither credit nor penalty.
6. Start at the neutral anchor `2` for global, sequence, conclusion, or
   whole-book criteria. Move only when the selected sample itself supplies
   direct evidence, list uncertain paths in `scope_limited_subcriteria`, and do
   not invent package-wide patterns. At minimum, list all four
   `domains.whole_book_coherence.subcriteria.*` paths as scope-limited.
7. Prefix every domain `whole_book_pattern` with `Sample-wide pattern:`. The
   phrase describes the selected sample, never the full book.
8. Set technical completeness to `conditional` when all sampled content is
   readable; it must never be `pass`. An observed sampled-content defect may
   instead make it `fail` or `unevaluable` under the rubric.
9. Set certification to `not_assessed` when sampled content is scoreable, to
   `fail` only for an observed eligible gate failure, or to `unevaluable` when
   the selected content cannot support a score. Sample mode is never eligible
   for full-book `pass` or `conditional` certification.
10. Begin the verdict with `Experimental four-chapter sample:`. For a
    three-chapter source use `Experimental three-chapter sample:`; for any other
    shorter source use `Experimental <n>-chapter sample:`.
11. Set `sample_scope_acknowledged` to true and
    `unsampled_content_claims_found` to false. Avoid “the book consistently,”
    “throughout the book,” “all chapters,” or equivalent claims unless the text
    explicitly and narrowly says “across the selected sample.”
12. Keep evidence and rationale concise: use short paraphrases and precise
    selected-package locators, never reproduced source text or speculative
    notes about unseen content.

A rating of 4 means exceptional evidence across the selected sample. It is not
proof of nearly book-wide performance.

## Sample-aware validation and adjudication

Validate blind results against `book-evaluation-sample.schema.json` and final
records against `adjudicated-book-sample.schema.json`. Sample-aware validation
must additionally verify:

- result `source_hash` equals the sampled-package hash;
- original source identity, public/per-book seeds, complete algorithm object,
  and selection-manifest hash match the job identity;
- selected chapter index/position/order/id/title sets match exactly;
- chapter evidence count equals the selected count and accounts for every
  selected chapter;
- no unselected locator or full-source claim appears;
- every `whole_book_pattern` and the verdict use the required prefixes;
- technical completeness is not `pass`;
- certification is `not_assessed`, `fail`, or `unevaluable` under the rules
  above; and
- all ordinary schema, evidence, gate, and arithmetic checks still pass.

Pass both the assigned sampled package and the book's generated exact scope
file to `validate_book_result.py` with `--sample-package` and
`--expected-evaluation-scope`. Do not reconstruct scope by hand in a worker.

The adjudicator uses only the sampled package and the two validated sample
results. It preserves their identical `evaluation_scope`, resolves differences
against sampled evidence rather than averaging, uses the same prefixes and
certification rules, and assigns low confidence to full-book inference even
when selected-sample coverage is 100%.

## Run and report metadata

The run manifest must declare `evaluation_mode: chapter_sample` and record the
protocol version, public seed, canonical algorithm name, copied selection
manifest paths and hash, population and selected chapter counts, unsampled
count, blind chapter reads, population coverage ratio, score label, scope
limitation, and `full_book_certification_eligible: false`.

Every offline report view must clearly state that scores, rankings, category
leaders, gates, recommendations, and comparisons are experimental selected-
chapter estimates. Use `sample coverage`, not `book completeness`, for the
selected/population ratio, and do not publish the run under a title that can be
confused with a full-catalog evaluation.
