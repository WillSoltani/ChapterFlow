---
name: chapterflow-book-evaluator
description: Evaluate nonfiction ChapterFlow book packages under book-packages/ using the ChapterFlow Evidence, Learning, and Reader Experience Rubric v2.0; by default read every chapter, fan out two independent raters per book, adjudicate disagreements, validate weighted scores, and generate a self-contained interactive HTML report plus JSON/CSV audit artifacts. Also supports an explicitly requested, clearly labeled experimental deterministic four-chapter sample mode. Use for ChapterFlow book scoring, chapter-level content audits, learning-design reviews, rubric-based comparisons, and book-package QA. Do not use for fiction reviews, external fact-checking unless explicitly enabled, or claims about actual reader outcomes without study data.
---

# ChapterFlow Book Evaluator

Run a complete, repository-local, evidence-first audit. Keep model judgment in blind worker records and keep discovery, validation, arithmetic, aggregation, and rendering deterministic.

## Non-negotiable boundaries

- Use only reader-facing package content and local metadata. Do not browse or use reputation, reviews, previous scores, or memory of the original book.
- Keep external factual verification disabled unless the user explicitly opts in. For an isolated run, mark external accuracy `not_assessed`.
- Describe design support for retention, transfer, action, and completion; never claim measured reader outcomes without study data.
- In the default full-content mode, read every accessible chapter and every reader-facing component before scoring. Never infer quality from component names or quantity. Use a chapter sample only when the user explicitly requests it and then follow the separate experimental protocol without full-book claims.
- Paraphrase evidence and cite local chapter/section/item locators. Do not reproduce chapters.
- Assess gates independently from the weighted score. A high score never erases a gate failure.
- Do not stop after implementation. When invoked for a repository evaluation, run the complete workflow through validated artifacts and `latest/` publication.

## Required references

Read each relevant reference completely before acting:

- Scoring: [rubric-v2.md](references/rubric-v2.md) and [scoring-protocol.md](references/scoring-protocol.md)
- Blind workers: [book-rater-prompt.md](references/book-rater-prompt.md) and [book-evaluation.schema.json](references/book-evaluation.schema.json)
- Adjudication: [adjudication-protocol.md](references/adjudication-protocol.md) and [adjudicated-book.schema.json](references/adjudicated-book.schema.json)
- Aggregation/reporting: [report-spec.md](references/report-spec.md) and [report-data.schema.json](references/report-data.schema.json)
- Below-80 remediation: [remediation-prompt-contract.md](references/remediation-prompt-contract.md)
- Explicit chapter samples only: [chapter-sample-protocol.md](references/chapter-sample-protocol.md), [book-rater-sample-prompt.md](references/book-rater-sample-prompt.md), [book-evaluation-sample.schema.json](references/book-evaluation-sample.schema.json), [adjudication-sample-prompt.md](references/adjudication-sample-prompt.md), and [adjudicated-book-sample.schema.json](references/adjudicated-book-sample.schema.json)

## Complete workflow

1. Resolve the repository root, read every applicable `AGENTS.md`, preserve unrelated changes, and verify `book-packages/` exists.
2. Merge project agent configuration without erasing existing settings. Use `.codex/agents/` raters, adjudicator, and report auditor when supported; inherit the selected model if `ultra` is unsupported.
3. Create `artifacts/chapterflow-evaluation/<UTC timestamp>-<short manifest hash>/` with `data`, `raw/{primary,verification,adjudicated}`, `jobs`, `logs`, and `tmp`.
4. Run `discover_packages.py` before fan-out. Safely inspect directories, JSON/text collections, and archives without executing package code. Record hashes, warnings, duplicates, and the canonical source in both manifests.
5. Run `inspect_package.py` for structural and diagnostic analytics. Treat its signals as prompts for human inspection, never automatic ratings.
6. Create `jobs/book-rater-jobs.csv` with exactly two unique blind jobs per canonical package: `primary` and `verification`.
7. Fan out jobs with CSV workers when available. Otherwise spawn direct fresh children in bounded batches no larger than the configured cap. Give each worker only its package, rubric, schema, role, source hash, and unique output path. Never expose the counterpart output.
8. Validate every worker result with `validate_book_result.py`. Reject wrong hashes, incomplete chapter coverage, missing evidence, non-integer primary ratings, bad arithmetic, outside-knowledge claims, or schema failures. Retry a failed job once with only the validator errors and record the retry.
9. For each book, give a separate adjudicator the source plus the two validated results. Adjudicate every difference from the anchors and evidence; never average automatically. Reinspect source for differences of 2+, gate conflicts, score gaps over five, or conflicting chapter/QA findings.
10. Validate each adjudicated record. Preserve primary, verification, final, rationale, agreement statistics, source rechecks, and confidence inputs.
11. After every book has its individual final result, run cross-book calibration. Reopen a rating only when the same anchor was demonstrably applied differently; never force a distribution. Log every change.
12. Run `aggregate_results.py`. Aggregate only adjudicated records, recalculate every score, and generate the canonical report dataset and deterministic CSV audit files.
13. Run `generate_remediation_prompts.py` on canonical `report-data.json`. Preserve one ledger entry for every raw overall, domain, or subcriterion score below 80%; generate one comprehensive, evidence-grounded, deduplicated implementation prompt for every book; and write JSON and Markdown prompt packs. Never let score lift override a gate.
14. Run `render_report.py` to create one offline, self-contained `report.html` from the remediation-enriched `report-data.json`.
15. Run the skill tests and `validate_report.py`. Validate exact remediation trigger counts, prompt coverage, evidence labels, and downloads in addition to the existing report contract. When an installed browser is available, smoke-test the file offline and check console errors; do not install a browser solely for this task.
16. Ask the report-auditor agent to check completeness, calculations, gate separation, traceability, calibration, remediation specificity, usability, injection safety, and unsupported outcome claims. Fix material findings and rerun affected validation.
17. Only after all checks pass, replace `artifacts/chapterflow-evaluation/latest/` transactionally with the completed run. Return exact artifact paths, package/chapter counts, ranking, gate issues, remediation totals, test status, and honest limitations.

## Explicit experimental chapter-sample mode

Use this branch only when the user explicitly asks for a chapter sample. The
default complete workflow above remains unchanged.

1. Create a fresh run and complete deterministic discovery before sampling. Do
   not convert a run that already has rater outputs.
2. Read [chapter-sample-protocol.md](references/chapter-sample-protocol.md) in
   full. Run `sample_chapters.py` with a public seed and preserve its JSON, CSV,
   sampled-package, and hash artifacts.
3. Run `prepare_sample_jobs.py` with the discovered run, JSON selection
   manifest, and both supplied sample-aware schemas. It verifies that the
   sampled set exactly equals the canonical discovered set, copies and hashes
   the selection manifests into `data/`, replaces the new run's standard job
   ledgers with exactly two blind jobs per book, and creates a longest-sampled-
   word-count-first queue. Every job points only to `raw/sample/` outputs and a
   sampled package inside the run.
4. Give primary and verification workers the same immutable sample identity,
   but keep their sessions and outputs blind. Use
   [book-rater-sample-prompt.md](references/book-rater-sample-prompt.md); never
   expose the original package path as an allowed input.
5. Validate against `book-evaluation-sample.schema.json`, including the
   assigned sampled package and expected evaluation scope. Retry one failed
   job only with its validator errors.
6. After both blind results validate, use a fresh adjudicator with only the
   sampled package and those two results. Follow
   [adjudication-sample-prompt.md](references/adjudication-sample-prompt.md) and
   `adjudicated-book-sample.schema.json`.
7. Keep technical completeness non-pass. Use certification `not_assessed`
   unless an observed eligible gate requires `fail` or selected content is
   `unevaluable`. Prefix every domain pattern `Sample-wide pattern:` and every
   verdict with the required experimental chapter-count prefix.
8. Aggregate, calibrate, report, validate, audit, and publish only with the
   sample-aware schemas and report path. Label all scores, ranks, gates, and
   recommendations experimental selected-chapter estimates; state that
   unsampled content may materially change every conclusion.
9. Generate the strict-below-80 remediation ledger from selected-chapter
   estimates only. Every prompt must remain limited to the sampled package and
   must not instruct changes to, or make claims about, unsampled chapters.

## Deterministic commands

Run from the repository root:

```bash
python3 .agents/skills/chapterflow-book-evaluator/scripts/discover_packages.py --packages-dir book-packages --run-dir artifacts/chapterflow-evaluation/<run-id>
python3 .agents/skills/chapterflow-book-evaluator/scripts/validate_book_result.py --schema .agents/skills/chapterflow-book-evaluator/references/book-evaluation.schema.json --input <result.json>
python3 .agents/skills/chapterflow-book-evaluator/scripts/aggregate_results.py --run-dir artifacts/chapterflow-evaluation/<run-id>
python3 .agents/skills/chapterflow-book-evaluator/scripts/generate_remediation_prompts.py --input artifacts/chapterflow-evaluation/<run-id>/data/report-data.json --output-report-data artifacts/chapterflow-evaluation/<run-id>/data/report-data.json --json-output artifacts/chapterflow-evaluation/<run-id>/data/remediation-prompts.json --markdown-output artifacts/chapterflow-evaluation/<run-id>/data/remediation-prompts.md
python3 .agents/skills/chapterflow-book-evaluator/scripts/render_report.py --data artifacts/chapterflow-evaluation/<run-id>/data/report-data.json --output artifacts/chapterflow-evaluation/<run-id>/report.html
python3 .agents/skills/chapterflow-book-evaluator/scripts/validate_report.py --report artifacts/chapterflow-evaluation/<run-id>/report.html --data artifacts/chapterflow-evaluation/<run-id>/data/report-data.json
python3 -m unittest discover -s .agents/skills/chapterflow-book-evaluator/tests -p 'test_*.py'
```

For an explicitly requested sample, run discovery first and then:

```bash
python3 .agents/skills/chapterflow-book-evaluator/scripts/sample_chapters.py --manifest artifacts/chapterflow-evaluation/<run-id>/data/package-manifest.csv --run-id <run-id> --seed <public-seed> --output-dir artifacts/chapterflow-evaluation/<run-id>/tmp/chapter-sample --repo-root .
python3 .agents/skills/chapterflow-book-evaluator/scripts/prepare_sample_jobs.py --run-dir artifacts/chapterflow-evaluation/<run-id> --sample-manifest artifacts/chapterflow-evaluation/<run-id>/tmp/chapter-sample/chapter-sample-manifest.json --rater-schema .agents/skills/chapterflow-book-evaluator/references/book-evaluation-sample.schema.json --adjudicated-schema .agents/skills/chapterflow-book-evaluator/references/adjudicated-book-sample.schema.json --repo-root .
```

Use atomic writes. Keep raw outputs. Do not update `latest/` after a partial run or failed validation.
