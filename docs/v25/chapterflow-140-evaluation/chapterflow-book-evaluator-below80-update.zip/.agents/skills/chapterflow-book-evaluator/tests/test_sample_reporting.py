"""Regression tests for additive experimental chapter-sample reporting."""

from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path


TESTS_DIR = Path(__file__).resolve().parent
SKILL_ROOT = TESTS_DIR.parent
SCRIPTS_DIR = SKILL_ROOT / "scripts"
for import_path in (SCRIPTS_DIR, TESTS_DIR):
    if str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from aggregate_results import aggregate  # noqa: E402
from common import EvaluationError, calculate_scores  # noqa: E402
from render_report import SAMPLE_WARNING, render_report  # noqa: E402
from test_validation import valid_result  # noqa: E402
from validate_report import AuditParser, validate_report, validate_sample_report  # noqa: E402


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _selected_chapters() -> list[dict[str, object]]:
    return [
        {
            "original_chapter_index": 1,
            "original_chapter_position": 2,
            "selection_order": 2,
            "chapter_id": "chapter-2",
            "chapter_number": 2,
            "chapter_title": "Notice",
            "chapter_fingerprint_sha256": "2" * 64,
            "selection_rank_sha256": "4" * 64,
        },
        {
            "original_chapter_index": 4,
            "original_chapter_position": 5,
            "selection_order": 1,
            "chapter_id": "chapter-5",
            "chapter_number": 5,
            "chapter_title": "Review",
            "chapter_fingerprint_sha256": "5" * 64,
            "selection_rank_sha256": "3" * 64,
        },
    ]


def _sample_record(role: str, scope: dict[str, object]) -> dict:
    record = valid_result(role=role)
    record.update(
        {
            "result_type": "experimental_chapter_sample_evaluation",
            "run_id": "sample-run",
            "job_id": f"fixture-book--{role}",
            "rater_role": role,
            "source_hash": "b" * 64,
            "evaluation_scope": copy.deepcopy(scope),
            "sample_scope_acknowledged": True,
            "unsampled_content_claims_found": False,
            "scope_limited_subcriteria": [
                "domains.whole_book_coherence.subcriteria.chapter_necessity_order",
                "domains.whole_book_coherence.subcriteria.quality_consistency_pacing",
                "domains.whole_book_coherence.subcriteria.redundancy_cumulative_load",
                "domains.whole_book_coherence.subcriteria.synthesis_completion_value",
            ],
        }
    )
    record["book"].update(
        {
            "package_path": "tmp/chapter-sample/sampled-packages/fixture-book.sampled.json",
            "chapter_count_expected": 2,
            "chapter_count_read_full": 2,
        }
    )
    for chapter, source_index, position, selection_order, chapter_id, title in zip(
        record["chapter_evidence"],
        (1, 4),
        (2, 5),
        (2, 1),
        ("chapter-2", "chapter-5"),
        ("Notice", "Review"),
        strict=True,
    ):
        chapter.update(
            {
                "chapter_index": position,
                "original_chapter_index": source_index,
                "original_chapter_position": position,
                "selection_order": selection_order,
                "chapter_id": chapter_id,
                "title": title,
            }
        )
        chapter["evidence"][0]["chapter"] = chapter_id
        chapter["evidence"][0]["package_path"] = record["book"]["package_path"]
    for domain in record["domains"].values():
        domain["whole_book_pattern"] = "Sample-wide pattern: the observe-review loop recurs."
        for criterion in domain["subcriteria"].values():
            criterion["strength_evidence"][0].update(
                {"chapter": "chapter-2", "package_path": record["book"]["package_path"]}
            )
            criterion["limitation_evidence"][0].update(
                {"chapter": "chapter-5", "package_path": record["book"]["package_path"]}
            )
    record["gates"]["technical_completeness"].update(
        {
            "status": "conditional",
            "rationale": "All selected chapters were readable; unsampled chapters were intentionally not assessed.",
        }
    )
    for gate_key in ("epistemic_instructional_safety", "ethics_reader_autonomy", "purpose_audience_declaration"):
        record["gates"][gate_key].update(
            {
                "status": "not_assessed",
                "rationale": "No full-book gate finding is made from selected chapters alone.",
            }
        )
    record["analysis"]["final_verdict"] = (
        "Experimental two-chapter sample: the selected content is coherent. "
        "Unsampled content may materially change this estimate."
    )
    calculate_scores(record)
    record["classification"] = "Exploratory sample estimate; no full-book classification"
    record["certification_status"] = "not_assessed"
    if role == "adjudicated":
        record["rater_agreement"] = {
            "mean_absolute_subcriterion_difference": 0.0,
            "maximum_subcriterion_difference": 0.0,
            "overall_score_difference": 0.0,
            "gate_conflicts": [],
            "disagreements": [],
        }
        record["confidence"] = {
            "level": "low",
            "rationale": "The selected content was read fully; full-book inference remains unavailable.",
            "chapter_completeness_ratio": 1.0,
            "package_ambiguity": "none",
            "unresolved_issues": ["Three source chapters were not sampled."],
        }
        record["calibration_changes"] = []
    return record


def _sample_run(root: Path) -> tuple[Path, dict[str, object]]:
    run_dir = root / "sample-run"
    selected = _selected_chapters()
    sample_book = {
        "book_id": "fixture-book",
        "canonical_title": "Synthetic Evaluation",
        "source_path": "book-packages/fixture-book.json",
        "sampled_package_path": "sampled-packages/fixture-book.sampled.json",
        "full_source_sha256": "a" * 64,
        "sampled_package_sha256": "b" * 64,
        "source_chapter_count": 5,
        "selected_chapter_count": 2,
        "per_book_seed_sha256": "c" * 64,
        "selected_chapters": selected,
    }
    selection_manifest = {
        "schema_version": "1.0.0",
        "run_id": "sample-run",
        "sample_mode": "deterministic-four-chapter-sample",
        "sampling_seed": "public-test-seed",
        "selection_method": {"name": "sha256-lowest-rank-v1"},
        "book_count": 1,
        "source_chapter_count": 5,
        "selected_chapter_count": 2,
        "books": [sample_book],
    }
    manifest_path = run_dir / "data" / "chapter-sample-manifest.json"
    _write_json(manifest_path, selection_manifest)
    manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    scope: dict[str, object] = {
        "protocol_version": "1.0.0",
        "mode": "chapter_sample",
        "sample_mode": "deterministic-four-chapter-sample",
        "inference_scope": "selected_chapters_only",
        "score_label": "Experimental four-chapter sample score",
        "public_seed": "public-test-seed",
        "per_book_seed_sha256": "c" * 64,
        "selection_algorithm": {"name": "sha256-lowest-rank-v1"},
        "selection_manifest_sha256": manifest_hash,
        "original_source": {
            "path": "book-packages/fixture-book.json",
            "sha256": "a" * 64,
            "chapter_count": 5,
        },
        "sampled_package_sha256": "b" * 64,
        "requested_chapter_count": 4,
        "selected_chapter_count": 2,
        "selected_chapters": selected,
        "scope_limitation": "Experimental chapter sample; results are not a full-book audit.",
        "full_book_certification_eligible": False,
    }
    run_manifest = {
        "schema_version": "2.0.0",
        "rubric_version": "2.0",
        "run_id": "sample-run",
        "generated_at_utc": "2026-07-10T00:00:00Z",
        "repository_root": str(root),
        "package_directory": "book-packages",
        "isolation_mode": "local sampled packages only",
        "external_verification_enabled": False,
        "status": "adjudicated",
        "evaluation_mode": "chapter_sample",
        "packages_found": 1,
        "canonical_books": 1,
        "duplicates": 0,
        "unscoreable_packages": 0,
        "chapters_expected": 5,
        "component_counts": {},
        "agent_configuration": {
            "requested_max_threads": 2,
            "max_depth": 1,
            "orchestration": "synthetic test",
        },
        "validation": {"tests": "passed", "book_results": "passed", "report": "pending", "audit": "pending"},
        "limitations": ["Only selected chapters were inspected."],
        "packages": [],
        "sampling": {
            "mode": "chapter_sample",
            "protocol_version": "1.0.0",
            "sample_mode": "deterministic-four-chapter-sample",
            "score_scope": "selected_chapters_only",
            "result_interpretation": "exploratory_sample_estimate",
            "score_label": "Experimental four-chapter sample score",
            "requested_chapters_per_book": 4,
            "sampling_seed": "public-test-seed",
            "selection_algorithm": "sha256-lowest-rank-v1",
            "selection_manifest_json": "data/chapter-sample-manifest.json",
            "selection_manifest_csv": "data/chapter-sample-manifest.csv",
            "selection_manifest_sha256": manifest_hash,
            "population_chapter_count": 5,
            "selected_chapter_count": 2,
            "not_sampled_chapter_count": 3,
            "blind_chapter_reads": 4,
            "population_coverage_ratio": 0.4,
            "full_book_certification_eligible": False,
            "scope_limitation": "Experimental chapter sample; results are not a full-book audit.",
        },
    }
    _write_json(run_dir / "data" / "run-manifest.json", run_manifest)
    (run_dir / "data" / "package-manifest.csv").write_text(
        "package_id,source_path\r\nfixture-book,book-packages/fixture-book.json\r\n",
        encoding="utf-8",
    )
    for role in ("primary", "verification", "adjudicated"):
        _write_json(run_dir / "raw" / role / "fixture-book.json", _sample_record(role, scope))
    return run_dir, scope


class SampleReportTests(unittest.TestCase):
    def test_sample_aggregation_adds_scope_columns_and_prominent_labels(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            run_dir, _scope = _sample_run(Path(temp_name))
            data = aggregate(run_dir, SKILL_ROOT)

            self.assertEqual("experimental_chapter_sample_report", data["result_type"])
            self.assertEqual(5, data["run"]["sampling"]["population_chapter_count"])
            self.assertEqual(2, data["run"]["sampling"]["selected_chapter_count"])
            self.assertEqual(3, data["run"]["sampling"]["not_sampled_chapter_count"])
            for filename in ("scorecard.csv", "gates.csv", "chapter-evidence.csv"):
                rows = list(csv.DictReader(io.StringIO(data["csv_downloads"][filename], newline="")))
                self.assertTrue(rows)
                self.assertTrue(SAMPLE_SCOPE_COLUMNS <= set(rows[0]))
                self.assertTrue(all(row["evaluation_mode"] == "chapter_sample" for row in rows))
                self.assertTrue(all(row["sample_selected_positions"] == "2;5" for row in rows))

            template = (SKILL_ROOT / "assets" / "report-template.html").read_text(encoding="utf-8")
            css = (SKILL_ROOT / "assets" / "report.css").read_text(encoding="utf-8")
            javascript = (SKILL_ROOT / "assets" / "report.js").read_text(encoding="utf-8")
            html = render_report(data, template, css, javascript)
            parser = AuditParser()
            parser.feed(html)
            errors: list[str] = []
            validate_sample_report(data, parser, errors)
            self.assertEqual([], errors)
            report_path = run_dir / "report.html"
            report_path.write_text(html, encoding="utf-8")
            report_data_path = run_dir / "data" / "report-data.json"
            report_errors = validate_report(report_path, report_data_path)
            self.assertEqual([], report_errors, "\n".join(report_errors))
            visible = " ".join(parser.visible_text)
            self.assertIn(SAMPLE_WARNING, visible)
            self.assertIn("Population chapters 5", visible)
            self.assertIn("Selected chapters 2", visible)
            self.assertIn("Not sampled 3", visible)
            self.assertIn("Selected source positions 2, 5", visible)
            self.assertNotIn("Every accessible reader-facing chapter and component was read", visible)

    def test_sample_aggregation_rejects_scope_drift_between_blind_records(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            run_dir, _scope = _sample_run(Path(temp_name))
            verification_path = run_dir / "raw" / "verification" / "fixture-book.json"
            verification = json.loads(verification_path.read_text(encoding="utf-8"))
            verification["evaluation_scope"]["selected_chapters"][0]["selection_order"] = 99
            _write_json(verification_path, verification)
            with self.assertRaisesRegex(EvaluationError, "differs between verification and adjudicated"):
                aggregate(run_dir, SKILL_ROOT)

    def test_sample_validator_rejects_full_content_methodology(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            run_dir, _scope = _sample_run(Path(temp_name))
            data = aggregate(run_dir, SKILL_ROOT)
            template = (SKILL_ROOT / "assets" / "report-template.html").read_text(encoding="utf-8")
            html = render_report(
                data,
                template,
                (SKILL_ROOT / "assets" / "report.css").read_text(encoding="utf-8"),
                (SKILL_ROOT / "assets" / "report.js").read_text(encoding="utf-8"),
            )
            html = html.replace(
                "Experimental chapter-sample methodology",
                "Experimental chapter-sample methodology</h3><p>Every accessible reader-facing chapter and component was read",
                1,
            )
            parser = AuditParser()
            parser.feed(html)
            errors: list[str] = []
            validate_sample_report(data, parser, errors)
            self.assertTrue(any("misleading full-content language" in error for error in errors))


SAMPLE_SCOPE_COLUMNS = {
    "evaluation_mode",
    "sample_source_chapter_count",
    "sample_selected_chapter_count",
    "sample_not_selected_chapter_count",
    "sample_selected_positions",
}


if __name__ == "__main__":
    unittest.main()
