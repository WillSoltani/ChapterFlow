"""Focused tests for deterministic chapter-sample job orchestration."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = SKILL_ROOT / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from common import EvaluationError  # noqa: E402
from discover_packages import discover  # noqa: E402
from prepare_sample_jobs import prepare_sample_jobs  # noqa: E402
from sample_chapters import sample_from_manifest  # noqa: E402


RATER_SCHEMA = SKILL_ROOT / "references" / "book-evaluation-sample.schema.json"
ADJUDICATED_SCHEMA = SKILL_ROOT / "references" / "adjudicated-book-sample.schema.json"


def write_package(path: Path, book_id: str, chapter_count: int, words_per_chapter: int) -> None:
    package = {
        "schemaVersion": "chapterflow-v21-authored",
        "packageId": f"package-{book_id}",
        "createdAt": "2026-07-10T00:00:00Z",
        "contentOwner": {"name": "Fixture Owner"},
        "book": {"bookId": book_id, "title": f"Fixture {book_id.title()}"},
        "chapters": [
            {
                "chapterId": f"{book_id}-chapter-{number}",
                "number": number,
                "title": f"Chapter {number}",
                "hook": " ".join(f"word-{number}-{index}" for index in range(words_per_chapter)),
                "keyTakeaway": f"Takeaway {number}",
                "examples": [{"title": "Example", "body": "A short synthetic example."}],
            }
            for number in range(1, chapter_count + 1)
        ],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def make_sample_run(root: Path) -> tuple[Path, Path]:
    packages = root / "book-packages"
    write_package(packages / "alpha.v21.json", "alpha", 7, 80)
    write_package(packages / "beta.v21.json", "beta", 3, 2)
    run = root / "artifacts" / "chapterflow-evaluation" / "run-sample"
    discover(packages, run, root)
    sample_output = run / "tmp" / "chapter-sample"
    sample_from_manifest(
        run / "data" / "package-manifest.csv",
        run.name,
        "public-seed-fixture",
        sample_output,
        root,
    )
    return run, sample_output / "chapter-sample-manifest.json"


class SampleJobPreparationTests(unittest.TestCase):
    def test_prepares_exact_blind_pairs_queue_ledgers_and_run_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            run, sample_manifest = make_sample_run(root)
            package_manifest_before = (run / "data" / "package-manifest.csv").read_bytes()
            source_before = {
                path.name: path.read_bytes() for path in sorted((root / "book-packages").glob("*.json"))
            }
            sentinel = run / "raw" / "primary" / "unrelated-note.txt"
            sentinel.write_text("preserve me", encoding="utf-8")

            summary = prepare_sample_jobs(
                run,
                sample_manifest,
                RATER_SCHEMA,
                ADJUDICATED_SCHEMA,
                repo_root=root,
            )

            self.assertEqual(2, summary["canonical_books"])
            self.assertEqual(4, summary["blind_jobs"])
            self.assertEqual(2, summary["adjudication_jobs"])
            self.assertEqual(7, summary["selected_chapter_count"])
            self.assertEqual(14, summary["blind_chapter_reads"])

            jobs = read_csv(run / "jobs" / "book-rater-jobs.csv")
            self.assertEqual(4, len(jobs))
            self.assertEqual(4, len({row["job_id"] for row in jobs}))
            self.assertEqual(4, len({row["output_path"] for row in jobs}))
            by_book: dict[str, list[dict[str, str]]] = {}
            for row in jobs:
                by_book.setdefault(row["book_id"], []).append(row)
                package_path = Path(row["package_path"])
                self.assertTrue(package_path.resolve().is_relative_to(run.resolve()))
                self.assertIn("sampled-packages", package_path.parts)
                self.assertNotEqual(
                    (root / "book-packages" / f"{row['book_id']}.v21.json").resolve(), package_path.resolve()
                )
                self.assertEqual(hashlib.sha256(package_path.read_bytes()).hexdigest(), row["source_hash"])
                self.assertEqual(row["source_hash"], row["sampled_package_sha256"])
                self.assertEqual("chapter_sample", row["evaluation_mode"])
                self.assertEqual("selected_chapters_only", row["inference_scope"])
                self.assertEqual("false", row["full_book_certification_eligible"])
                self.assertEqual(str(RATER_SCHEMA.resolve()), row["schema_path"])
                self.assertIn("/raw/sample/", row["output_path"])
                scope_path = Path(row["evaluation_scope_path"])
                self.assertTrue(scope_path.is_file())
                self.assertTrue(
                    scope_path.resolve().is_relative_to((run / "jobs" / "evaluation-scopes").resolve())
                )
                self.assertEqual(hashlib.sha256(scope_path.read_bytes()).hexdigest(), row["evaluation_scope_sha256"])
                scope = json.loads(scope_path.read_text(encoding="utf-8"))
                self.assertEqual("chapter_sample", scope["mode"])
                self.assertEqual(row["source_hash"], scope["sampled_package_sha256"])
                self.assertEqual(summary["selection_manifest_sha256"], scope["selection_manifest_sha256"])
            for pair in by_book.values():
                self.assertEqual({"primary", "verification"}, {row["rater_role"] for row in pair})
                ignored = {"job_id", "rater_role", "output_path"}
                self.assertEqual(
                    {key: value for key, value in pair[0].items() if key not in ignored},
                    {key: value for key, value in pair[1].items() if key not in ignored},
                )

            queue = read_csv(run / "jobs" / "book-rater-queue.csv")
            self.assertEqual(["1", "2", "3", "4"], [row["queue_rank"] for row in queue])
            self.assertEqual(["alpha", "alpha", "beta", "beta"], [row["book_id"] for row in queue])
            self.assertGreater(int(queue[0]["sampled_word_count"]), int(queue[-1]["sampled_word_count"]))

            self.assertEqual([], read_csv(run / "jobs" / "book-rater-results.csv"))
            adjudication_jobs = read_csv(run / "jobs" / "adjudication-jobs.csv")
            self.assertEqual(2, len(adjudication_jobs))
            self.assertEqual(2, len({row["output_path"] for row in adjudication_jobs}))
            self.assertTrue(all("/raw/sample/adjudicated/" in row["output_path"] for row in adjudication_jobs))
            self.assertEqual([], read_csv(run / "jobs" / "adjudication-results.csv"))

            copied_manifest = run / "data" / "chapter-sample-manifest.json"
            copied_csv = run / "data" / "chapter-sample-manifest.csv"
            self.assertEqual(sample_manifest.read_bytes(), copied_manifest.read_bytes())
            self.assertEqual(sample_manifest.with_suffix(".csv").read_bytes(), copied_csv.read_bytes())
            selection_hash = hashlib.sha256(copied_manifest.read_bytes()).hexdigest()
            self.assertEqual(selection_hash, summary["selection_manifest_sha256"])

            run_manifest = json.loads((run / "data" / "run-manifest.json").read_text(encoding="utf-8"))
            self.assertEqual("chapter_sample", run_manifest["evaluation_mode"])
            self.assertEqual("sample-jobs-ready", run_manifest["status"])
            sampling = run_manifest["sampling"]
            self.assertEqual("1.0.0", sampling["protocol_version"])
            self.assertEqual("selected_chapters_only", sampling["score_scope"])
            self.assertEqual("exploratory_sample_estimate", sampling["result_interpretation"])
            self.assertEqual("sha256-lowest-rank-v1", sampling["selection_algorithm"])
            self.assertEqual(10, sampling["population_chapter_count"])
            self.assertEqual(7, sampling["selected_chapter_count"])
            self.assertEqual(3, sampling["not_sampled_chapter_count"])
            self.assertEqual(14, sampling["blind_chapter_reads"])
            self.assertEqual(0.7, sampling["population_coverage_ratio"])
            self.assertFalse(sampling["full_book_certification_eligible"])
            self.assertEqual(selection_hash, sampling["selection_manifest_sha256"])

            self.assertEqual(package_manifest_before, (run / "data" / "package-manifest.csv").read_bytes())
            self.assertEqual("preserve me", sentinel.read_text(encoding="utf-8"))
            self.assertEqual(
                source_before,
                {path.name: path.read_bytes() for path in sorted((root / "book-packages").glob("*.json"))},
            )

            generated = [
                run / "jobs" / name
                for name in (
                    "book-rater-jobs.csv",
                    "book-rater-queue.csv",
                    "book-rater-results.csv",
                    "adjudication-jobs.csv",
                    "adjudication-results.csv",
                )
            ] + [run / "data" / "chapter-sample-manifest.json", run / "data" / "run-manifest.json"]
            first_bytes = {path: path.read_bytes() for path in generated}
            second_summary = prepare_sample_jobs(
                run,
                sample_manifest,
                RATER_SCHEMA,
                ADJUDICATED_SCHEMA,
                repo_root=root,
            )
            self.assertEqual(summary, second_summary)
            self.assertEqual(first_bytes, {path: path.read_bytes() for path in generated})

    def test_mismatched_sample_fails_before_replacing_discovery_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            run, sample_manifest = make_sample_run(root)
            jobs_before = (run / "jobs" / "book-rater-jobs.csv").read_bytes()
            run_manifest_before = (run / "data" / "run-manifest.json").read_bytes()
            value = json.loads(sample_manifest.read_text(encoding="utf-8"))
            value["books"][0]["sampled_package_sha256"] = "0" * 64
            sample_manifest.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

            with self.assertRaisesRegex(EvaluationError, "cannot resolve sampled package"):
                prepare_sample_jobs(
                    run,
                    sample_manifest,
                    RATER_SCHEMA,
                    ADJUDICATED_SCHEMA,
                    repo_root=root,
                )

            self.assertEqual(jobs_before, (run / "jobs" / "book-rater-jobs.csv").read_bytes())
            self.assertEqual(run_manifest_before, (run / "data" / "run-manifest.json").read_bytes())
            self.assertFalse((run / "data" / "chapter-sample-manifest.json").exists())

    def test_refuses_to_convert_a_run_with_existing_rating_output(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            run, sample_manifest = make_sample_run(root)
            existing = run / "raw" / "primary" / "alpha.json"
            existing.write_text("{}\n", encoding="utf-8")

            with self.assertRaisesRegex(EvaluationError, "fresh discovered run"):
                prepare_sample_jobs(
                    run,
                    sample_manifest,
                    RATER_SCHEMA,
                    ADJUDICATED_SCHEMA,
                    repo_root=root,
                )

            self.assertEqual("{}\n", existing.read_text(encoding="utf-8"))

    def test_rejects_the_full_book_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            run, sample_manifest = make_sample_run(root)
            with self.assertRaisesRegex(EvaluationError, "not sample-aware"):
                prepare_sample_jobs(
                    run,
                    sample_manifest,
                    SKILL_ROOT / "references" / "book-evaluation.schema.json",
                    ADJUDICATED_SCHEMA,
                    repo_root=root,
                )


if __name__ == "__main__":
    unittest.main()
