"""Regression tests for the additive experimental chapter-sample contract."""

from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = SKILL_ROOT.parents[2]
SCRIPTS_DIR = SKILL_ROOT / "scripts"
TESTS_DIR = Path(__file__).resolve().parent
for path in (SCRIPTS_DIR, TESTS_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from common import (  # noqa: E402
    DOMAINS,
    SAMPLE_CLASSIFICATION,
    SAMPLE_RESULT_TYPE,
    calculate_scores,
    derive_sample_certification,
    evaluation_scope_from_sample_metadata,
    rating_paths,
    reference_standard_eligible,
)
from test_validation import valid_result  # noqa: E402
from validate_book_result import validate_result  # noqa: E402


SAMPLED_HASH = "b" * 64
MANIFEST_HASH = "c" * 64
FULL_HASH = "d" * 64


def _selected_chapters() -> list[dict]:
    return [
        {
            "original_chapter_index": index,
            "original_chapter_position": index + 1,
            "selection_order": selection_order,
            "chapter_id": f"chapter-{index + 1}",
            "chapter_number": index + 1,
            "chapter_title": f"Chapter {index + 1}",
            "chapter_fingerprint_sha256": character * 64,
            "selection_rank_sha256": rank_character * 64,
        }
        for index, selection_order, character, rank_character in (
            (0, 2, "1", "5"),
            (3, 4, "2", "6"),
            (7, 1, "3", "7"),
            (9, 3, "4", "8"),
        )
    ]


def sample_metadata() -> dict:
    return {
        "run_id": "fixture-run",
        "book_id": "fixture-book",
        "mode": "deterministic-four-chapter-sample",
        "public_seed": "fixture-public-seed",
        "per_book_seed_sha256": "e" * 64,
        "algorithm": {
            "name": "sha256-lowest-rank-v1",
            "sample_size_per_book": 4,
            "per_book_seed": "fixture seed derivation",
            "chapter_fingerprint": "fixture fingerprint derivation",
            "chapter_rank": "fixture rank derivation",
            "selection": "fixture deterministic selection",
            "sampled_view_order": "Original source chapter order.",
        },
        "original_source": {
            "path": "book-packages/fixture-book.v21.json",
            "sha256": FULL_HASH,
            "chapter_count": 12,
        },
        "requested_chapter_count": 4,
        "actual_chapter_count": 4,
        "selected_chapters": _selected_chapters(),
    }


def sample_scope() -> dict:
    return evaluation_scope_from_sample_metadata(
        sample_metadata(),
        sampled_package_sha256=SAMPLED_HASH,
        selection_manifest_sha256=MANIFEST_HASH,
        scope_limitation="Selected chapters only; unsampled content may materially change the estimate.",
    )


def sample_result(*, role: str = "primary", rating: float = 3) -> dict:
    result = valid_result(role=role, rating=rating)
    result.update(
        {
            "result_type": SAMPLE_RESULT_TYPE,
            "source_hash": SAMPLED_HASH,
            "evaluation_scope": sample_scope(),
            "sample_scope_acknowledged": True,
            "unsampled_content_claims_found": False,
            "scope_limited_subcriteria": [
                f"domains.{domain}.subcriteria.{subcriterion}"
                for domain, subcriterion in rating_paths()
                if domain == "whole_book_coherence"
            ],
        }
    )
    result["book"].update(
        {
            "package_path": "tmp/chapter-samples/sampled-packages/fixture-book.sampled.json",
            "chapter_count_expected": 4,
            "chapter_count_read_full": 4,
            "chapter_count_partial": 0,
            "chapter_count_inaccessible": 0,
            "all_accessible_chapters_read": True,
        }
    )
    chapter_template = result["chapter_evidence"][0]
    result["chapter_evidence"] = []
    for selection in _selected_chapters():
        chapter = copy.deepcopy(chapter_template)
        chapter.update(
            {
                "chapter_index": selection["original_chapter_position"],
                "original_chapter_index": selection["original_chapter_index"],
                "original_chapter_position": selection["original_chapter_position"],
                "selection_order": selection["selection_order"],
                "chapter_id": selection["chapter_id"],
                "title": selection["chapter_title"],
                "evidence": [
                    {
                        "package_path": result["book"]["package_path"],
                        "chapter": (
                            f"Original chapter {selection['original_chapter_position']}: "
                            f"{selection['chapter_title']}"
                        ),
                        "section": "fixture section",
                        "item_id": None,
                        "paraphrase": "Synthetic selected-sample evidence supports this test judgment.",
                    }
                ],
            }
        )
        result["chapter_evidence"].append(chapter)
    for domain in result["domains"].values():
        domain["whole_book_pattern"] = "Sample-wide pattern: the selected chapters use a compact observe-review loop."
    result["gates"] = {
        "technical_completeness": {
            "status": "conditional",
            "rationale": "All selected chapters are readable; unsampled chapters were not assessed.",
            "evidence": [],
        },
        "epistemic_instructional_safety": {
            "status": "not_assessed",
            "rationale": "No full-book gate finding is made from selected chapters alone.",
            "evidence": [],
        },
        "ethics_reader_autonomy": {
            "status": "not_assessed",
            "rationale": "No full-book gate finding is made from selected chapters alone.",
            "evidence": [],
        },
        "purpose_audience_declaration": {
            "status": "not_assessed",
            "rationale": "No full-book gate finding is made from selected chapters alone.",
            "evidence": [],
        },
        "external_accuracy": {
            "status": "not_assessed",
            "rationale": "External verification is outside the isolated sample experiment.",
            "evidence": [],
        },
    }
    result["analysis"]["overall_reader_experience"] = (
        "Across the selected sample, the observable design follows a clear learning path."
    )
    result["analysis"]["weakest_qualities"] = ["The selected sample cannot establish full-book consistency."]
    result["analysis"]["final_verdict"] = (
        "Experimental four-chapter sample: the selected chapters provide a useful exploratory estimate; "
        "unsampled content may materially change it."
    )
    calculate_scores(result)
    return result


class SampleScoringTests(unittest.TestCase):
    def test_sample_score_never_becomes_a_full_book_classification_or_reference_standard(self) -> None:
        record = sample_result(rating=4)

        self.assertEqual(100.0, record["overall_score"])
        self.assertEqual(SAMPLE_CLASSIFICATION, record["classification"])
        self.assertEqual("not_assessed", record["certification_status"])
        self.assertFalse(reference_standard_eligible(record))

    def test_sample_certification_is_fail_unevaluable_or_not_assessed(self) -> None:
        gates = sample_result()["gates"]
        self.assertEqual("not_assessed", derive_sample_certification(gates, selected_content_sufficient=True))

        gates["ethics_reader_autonomy"]["status"] = "fail"
        self.assertEqual("fail", derive_sample_certification(gates, selected_content_sufficient=True))

        gates["ethics_reader_autonomy"]["status"] = "not_assessed"
        self.assertEqual("unevaluable", derive_sample_certification(gates, selected_content_sufficient=False))


class SampleValidationTests(unittest.TestCase):
    def test_valid_blind_sample_is_accepted_without_weakening_full_mode(self) -> None:
        self.assertEqual([], validate_result(sample_result()))
        self.assertEqual([], validate_result(valid_result()))

    def test_sample_identity_classification_and_certification_are_fixed(self) -> None:
        mutations = (
            ("result_type", "full_book_evaluation", "result_type"),
            ("sample_scope_acknowledged", False, "sample_scope_acknowledged"),
            ("unsampled_content_claims_found", True, "unsampled_content_claims_found"),
            ("classification", "Strong design with identifiable improvements", "classification"),
            ("certification_status", "pass", "certification_status"),
        )
        for key, value, expected_fragment in mutations:
            with self.subTest(key=key):
                record = sample_result()
                record[key] = value
                self.assertTrue(any(expected_fragment in error for error in validate_result(record)))

    def test_sample_scope_hash_counts_and_selected_identity_are_exact(self) -> None:
        record = sample_result()
        record["source_hash"] = "0" * 64
        self.assertTrue(any("sampled_package_sha256" in error for error in validate_result(record)))

        record = sample_result()
        record["book"]["chapter_count_expected"] = 3
        self.assertTrue(any("selected_chapter_count" in error for error in validate_result(record)))

        record = sample_result()
        record["chapter_evidence"][1]["original_chapter_position"] = 5
        self.assertTrue(any("selected chapter" in error for error in validate_result(record)))

        record = sample_result()
        record["evaluation_scope"]["selected_chapters"][0]["chapter_title"] = "Wrong title"
        errors = validate_result(record, expected_evaluation_scope=sample_scope())
        self.assertTrue(any("evaluation_scope mismatch" in error for error in errors))

    def test_gate_contract_and_insufficient_selected_content_drive_certification(self) -> None:
        record = sample_result()
        record["gates"]["technical_completeness"]["status"] = "pass"
        self.assertTrue(any("technical_completeness" in error for error in validate_result(record)))

        record = sample_result()
        record["gates"]["epistemic_instructional_safety"]["status"] = "conditional"
        self.assertTrue(any("epistemic_instructional_safety" in error for error in validate_result(record)))

        record = sample_result()
        record["book"]["chapter_count_read_full"] = 3
        record["book"]["chapter_count_inaccessible"] = 1
        record["book"]["all_accessible_chapters_read"] = True
        record["chapter_evidence"][-1]["read_status"] = "inaccessible"
        record["chapter_evidence"][-1]["evidence"] = []
        record["gates"]["technical_completeness"]["status"] = "unevaluable"
        calculate_scores(record)
        self.assertEqual("unevaluable", record["certification_status"])
        self.assertEqual([], validate_result(record))

        record = sample_result()
        record["gates"]["epistemic_instructional_safety"]["status"] = "fail"
        record["gates"]["epistemic_instructional_safety"]["evidence"] = [
            record["chapter_evidence"][0]["evidence"][0]
        ]
        calculate_scores(record)
        self.assertEqual("fail", record["certification_status"])
        self.assertEqual([], validate_result(record))

    def test_sample_disclosures_and_scope_limited_paths_are_enforced(self) -> None:
        record = sample_result()
        next(iter(record["domains"].values()))["whole_book_pattern"] = "The selected chapters show a pattern."
        self.assertTrue(any("Sample-wide pattern:" in error for error in validate_result(record)))

        record = sample_result()
        record["analysis"]["final_verdict"] = "The selected sample is promising."
        self.assertTrue(any("final_verdict" in error for error in validate_result(record)))

        record = sample_result()
        record["analysis"]["overall_reader_experience"] = "The book consistently uses effective retrieval practice."
        self.assertTrue(any("unqualified full-book claim" in error for error in validate_result(record)))

        record = sample_result()
        record["scope_limited_subcriteria"] = ["domains.not_a_domain.subcriteria.not_a_criterion"]
        self.assertTrue(any("scope_limited_subcriteria" in error for error in validate_result(record)))


class SampleSchemaAndCliTests(unittest.TestCase):
    def test_generated_sample_schemas_are_deterministic_and_additive(self) -> None:
        build_script = SCRIPTS_DIR / "build_sample_schemas.py"
        base_blind = json.loads((SKILL_ROOT / "references" / "book-evaluation.schema.json").read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as temp_name:
            output_dir = Path(temp_name)
            completed = subprocess.run(
                [sys.executable, str(build_script), "--output-dir", str(output_dir)],
                cwd=REPO_ROOT,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
            self.assertEqual(
                {
                    "adjudicated": "adjudicated-book-sample.schema.json",
                    "blind": "book-evaluation-sample.schema.json",
                    "report": "report-data-sample.schema.json",
                },
                json.loads(completed.stdout),
            )
            generated_blind = json.loads((output_dir / "book-evaluation-sample.schema.json").read_text(encoding="utf-8"))
            committed_blind = json.loads(
                (SKILL_ROOT / "references" / "book-evaluation-sample.schema.json").read_text(encoding="utf-8")
            )
            self.assertEqual(committed_blind, generated_blind)
            self.assertEqual([], validate_result(sample_result(), schema=generated_blind))
            self.assertNotEqual([], validate_result(valid_result(), schema=generated_blind))
        self.assertEqual(
            base_blind,
            json.loads((SKILL_ROOT / "references" / "book-evaluation.schema.json").read_text(encoding="utf-8")),
        )

    def test_cli_checks_sample_package_hash_embedded_metadata_and_expected_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            metadata = sample_metadata()
            sampled_chapters = [
                {
                    "chapterId": selection["chapter_id"],
                    "number": selection["chapter_number"],
                    "title": selection["chapter_title"],
                }
                for selection in metadata["selected_chapters"]
            ]
            for chapter, selection in zip(sampled_chapters, metadata["selected_chapters"]):
                selection["chapter_fingerprint_sha256"] = hashlib.sha256(
                    json.dumps(chapter, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest()
            package = {
                "book": {"bookId": "fixture-book", "title": "Fixture Book"},
                "_chapterflowEvaluationSample": metadata,
                "chapters": sampled_chapters,
            }
            package_path = root / "fixture.sampled.json"
            package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            package_hash = hashlib.sha256(package_path.read_bytes()).hexdigest()
            scope = evaluation_scope_from_sample_metadata(
                metadata,
                sampled_package_sha256=package_hash,
                selection_manifest_sha256=MANIFEST_HASH,
                scope_limitation="Selected chapters only; unsampled content may materially change the estimate.",
            )
            record = sample_result()
            record["source_hash"] = package_hash
            record["evaluation_scope"] = scope
            input_path = root / "result.json"
            input_path.write_text(json.dumps(record), encoding="utf-8")
            scope_path = root / "expected-scope.json"
            scope_path.write_text(json.dumps(scope), encoding="utf-8")
            command = [
                sys.executable,
                str(SCRIPTS_DIR / "validate_book_result.py"),
                "--input",
                str(input_path),
                "--schema",
                str(SKILL_ROOT / "references" / "book-evaluation-sample.schema.json"),
                "--sample-package",
                str(package_path),
                "--expected-evaluation-scope",
                str(scope_path),
                "--json",
            ]

            completed = subprocess.run(command, cwd=REPO_ROOT, text=True, capture_output=True, check=False)

            self.assertEqual(0, completed.returncode, completed.stderr or completed.stdout)
            self.assertTrue(json.loads(completed.stdout)["valid"])


if __name__ == "__main__":
    unittest.main()
