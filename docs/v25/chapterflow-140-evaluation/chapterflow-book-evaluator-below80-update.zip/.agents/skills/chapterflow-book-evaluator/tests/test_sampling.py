"""Synthetic tests for deterministic four-chapter sampling."""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = SKILL_ROOT.parents[2]
SCRIPTS_DIR = SKILL_ROOT / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from common import EvaluationError  # noqa: E402
from sample_chapters import (  # noqa: E402
    chapter_fingerprint,
    derive_book_seed,
    sample_from_manifest,
    select_chapters,
)


MANIFEST_FIELDS = (
    "package_id",
    "canonical_title",
    "source_path",
    "canonical_path",
    "package_format",
    "source_hash",
    "content_hash",
    "detected_chapter_count",
    "package_byte_size",
    "duplicate_of_id",
    "discovery_warnings",
    "output_slug",
    "canonical",
    "scoreable",
)


def write_package(path: Path, book_id: str, chapter_count: int) -> dict[str, object]:
    package: dict[str, object] = {
        "schemaVersion": "chapterflow-v21-authored",
        "packageId": f"package-{book_id}",
        "createdAt": "2026-07-10T00:00:00Z",
        "contentOwner": {"name": "Fixture Owner"},
        "book": {"bookId": book_id, "title": f"Fixture {book_id.title()}"},
        "chapters": [
            {
                "chapterId": f"{book_id}-chapter-{number}",
                "number": number,
                "title": f"Chapter {number}",
                "hook": f"Hook {number}",
                "keyTakeaway": f"Takeaway {number}",
                "examples": [{"title": f"Example {number}", "body": "Synthetic evidence."}],
            }
            for number in range(1, chapter_count + 1)
        ],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return package


def source_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest_row(repo_root: Path, package_path: Path, book_id: str, chapter_count: int) -> dict[str, object]:
    relative = package_path.relative_to(repo_root).as_posix()
    return {
        "package_id": book_id,
        "canonical_title": f"Fixture {book_id.title()}",
        "source_path": relative,
        "canonical_path": relative,
        "package_format": "json",
        "source_hash": source_sha256(package_path),
        "content_hash": f"content-{book_id}",
        "detected_chapter_count": chapter_count,
        "package_byte_size": package_path.stat().st_size,
        "duplicate_of_id": "",
        "discovery_warnings": "[]",
        "output_slug": book_id,
        "canonical": "true",
        "scoreable": "true",
    }


def write_manifest(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=MANIFEST_FIELDS, lineterminator="\r\n")
        writer.writeheader()
        writer.writerows(rows)


class ChapterSelectionTests(unittest.TestCase):
    def test_sha256_ranking_is_order_independent_and_selected_view_uses_source_order(self) -> None:
        chapters = [
            {"chapterId": f"chapter-{number}", "number": number, "title": f"Chapter {number}"}
            for number in range(1, 10)
        ]
        book_seed = derive_book_seed("experiment-seed", "a" * 64, "fixture-book")
        self.assertEqual(
            hashlib.sha256(f"experiment-seed\0{'a' * 64}\0fixture-book".encode("utf-8")).hexdigest(),
            book_seed,
        )

        forward = select_chapters(chapters, book_seed)
        reverse = select_chapters(list(reversed(chapters)), book_seed)

        self.assertEqual(
            {item["chapter_id"] for item in forward},
            {item["chapter_id"] for item in reverse},
        )
        self.assertEqual(4, len(forward))
        self.assertEqual(sorted(item["original_chapter_index"] for item in forward), [item["original_chapter_index"] for item in forward])
        self.assertEqual(sorted(item["original_chapter_index"] for item in reverse), [item["original_chapter_index"] for item in reverse])

        expected = sorted(
            chapters,
            key=lambda chapter: hashlib.sha256(
                f"{book_seed}\0{chapter_fingerprint(chapter)}".encode("utf-8")
            ).hexdigest(),
        )[:4]
        self.assertEqual(
            {chapter["chapterId"] for chapter in expected},
            {item["chapter_id"] for item in forward},
        )

    def test_fewer_than_four_selects_every_chapter_once(self) -> None:
        chapters = [
            {"chapterId": f"short-{number}", "number": number, "title": f"Short {number}"}
            for number in range(1, 4)
        ]

        selected = select_chapters(chapters, "b" * 64)

        self.assertEqual(3, len(selected))
        self.assertEqual([0, 1, 2], [item["original_chapter_index"] for item in selected])
        self.assertEqual(3, len({item["chapter_id"] for item in selected}))


class SamplingManifestTests(unittest.TestCase):
    def test_manifest_order_does_not_change_outputs_and_hashes_are_traceable(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            alpha_path = root / "book-packages" / "alpha.v21.json"
            beta_path = root / "book-packages" / "beta.v21.json"
            alpha = write_package(alpha_path, "alpha", 7)
            beta = write_package(beta_path, "beta", 3)
            rows = [manifest_row(root, alpha_path, "alpha", 7), manifest_row(root, beta_path, "beta", 3)]
            first_manifest = root / "manifest-first.csv"
            second_manifest = root / "manifest-second.csv"
            write_manifest(first_manifest, rows)
            write_manifest(second_manifest, list(reversed(rows)))

            first_output = root / "sample-first"
            second_output = root / "sample-second"
            first = sample_from_manifest(first_manifest, "run-fixture", "seed-fixture", first_output, root)
            second = sample_from_manifest(second_manifest, "run-fixture", "seed-fixture", second_output, root)

            self.assertEqual(first, second)
            self.assertEqual(
                (first_output / "chapter-sample-manifest.csv").read_bytes(),
                (second_output / "chapter-sample-manifest.csv").read_bytes(),
            )
            self.assertEqual(2, first["book_count"])
            self.assertEqual(7, first["selected_chapter_count"])

            for source, original, expected_count in ((alpha_path, alpha, 4), (beta_path, beta, 3)):
                book_id = original["book"]["bookId"]  # type: ignore[index]
                record = next(book for book in first["books"] if book["book_id"] == book_id)
                sampled_path = first_output / record["sampled_package_path"]
                sampled = json.loads(sampled_path.read_text(encoding="utf-8"))
                self.assertEqual(expected_count, len(sampled["chapters"]))
                self.assertEqual(expected_count, len({chapter["chapterId"] for chapter in sampled["chapters"]}))
                self.assertEqual(
                    {key: value for key, value in original.items() if key != "chapters"},
                    {
                        key: value
                        for key, value in sampled.items()
                        if key not in {"chapters", "_chapterflowEvaluationSample"}
                    },
                )
                selected_indexes = [chapter["original_chapter_index"] for chapter in record["selected_chapters"]]
                self.assertEqual(sorted(selected_indexes), selected_indexes)
                self.assertEqual(
                    [original["chapters"][index] for index in selected_indexes],  # type: ignore[index]
                    sampled["chapters"],
                )
                self.assertEqual(source_sha256(source), record["full_source_sha256"])
                self.assertEqual(source_sha256(sampled_path), record["sampled_package_sha256"])
                scope = sampled["_chapterflowEvaluationSample"]
                self.assertEqual("run-fixture", scope["run_id"])
                self.assertEqual(book_id, scope["book_id"])
                self.assertEqual("deterministic-four-chapter-sample", scope["mode"])
                self.assertEqual("seed-fixture", scope["public_seed"])
                self.assertEqual(record["per_book_seed_sha256"], scope["per_book_seed_sha256"])
                self.assertEqual("sha256-lowest-rank-v1", scope["algorithm"]["name"])
                self.assertEqual(
                    {
                        "path": record["source_path"],
                        "sha256": record["full_source_sha256"],
                        "chapter_count": record["source_chapter_count"],
                    },
                    scope["original_source"],
                )
                self.assertEqual(4, scope["requested_chapter_count"])
                self.assertEqual(expected_count, scope["actual_chapter_count"])
                self.assertEqual(record["selected_chapters"], scope["selected_chapters"])
                self.assertNotIn("sampled_package_sha256", scope)

    def test_source_hash_mismatch_fails_before_writing_a_selection_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            package_path = root / "book-packages" / "alpha.v21.json"
            write_package(package_path, "alpha", 5)
            row = manifest_row(root, package_path, "alpha", 5)
            row["source_hash"] = "0" * 64
            manifest = root / "manifest.csv"
            output = root / "sample"
            write_manifest(manifest, [row])

            with self.assertRaisesRegex(EvaluationError, "source hash mismatch"):
                sample_from_manifest(manifest, "run-fixture", "seed-fixture", output, root)

            self.assertFalse((output / "chapter-sample-manifest.json").exists())
            self.assertFalse((output / "chapter-sample-manifest.csv").exists())

    def test_cli_emits_machine_readable_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            package_path = root / "book-packages" / "alpha.v21.json"
            write_package(package_path, "alpha", 6)
            manifest = root / "manifest.csv"
            output = root / "sample"
            write_manifest(manifest, [manifest_row(root, package_path, "alpha", 6)])
            command = [
                sys.executable,
                str(SCRIPTS_DIR / "sample_chapters.py"),
                "--manifest",
                str(manifest),
                "--run-id",
                "run-cli",
                "--seed",
                "seed-cli",
                "--output-dir",
                str(output),
                "--repo-root",
                str(root),
            ]

            completed = subprocess.run(command, cwd=REPO_ROOT, text=True, capture_output=True, check=False)

            self.assertEqual(0, completed.returncode, completed.stderr)
            self.assertEqual(
                {"book_count": 1, "run_id": "run-cli", "selected_chapter_count": 4},
                json.loads(completed.stdout),
            )


if __name__ == "__main__":
    unittest.main()
