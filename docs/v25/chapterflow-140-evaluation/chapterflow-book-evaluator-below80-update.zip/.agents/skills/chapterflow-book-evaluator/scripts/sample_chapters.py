#!/usr/bin/env python3
"""Create reproducible four-chapter views from a canonical package manifest."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from common import EvaluationError, atomic_write_json, sha256_file, slugify, write_csv


SAMPLE_SIZE = 4
SAMPLE_SCHEMA_VERSION = "1.0.0"
SELECTION_CSV_FIELDS = (
    "run_id",
    "sample_mode",
    "sampling_seed",
    "book_id",
    "canonical_title",
    "source_path",
    "sampled_package_path",
    "full_source_sha256",
    "sampled_package_sha256",
    "source_chapter_count",
    "selected_chapter_count",
    "per_book_seed_sha256",
    "original_chapter_index",
    "original_chapter_position",
    "selection_order",
    "chapter_id",
    "chapter_number",
    "chapter_title",
    "chapter_fingerprint_sha256",
    "selection_rank_sha256",
)
SAMPLE_MODE = "deterministic-four-chapter-sample"
_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def derive_book_seed(seed: str, source_hash: str, book_id: str) -> str:
    """Derive an independent book seed with unambiguous NUL-delimited inputs."""
    return hashlib.sha256(f"{seed}\0{source_hash}\0{book_id}".encode("utf-8")).hexdigest()


def chapter_fingerprint(chapter: Mapping[str, Any]) -> str:
    """Hash one chapter's complete canonical JSON representation."""
    encoded = json.dumps(
        chapter,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def select_chapters(
    chapters: Sequence[Mapping[str, Any]],
    per_book_seed: str,
    sample_size: int = SAMPLE_SIZE,
) -> list[dict[str, Any]]:
    """Select the lowest deterministic SHA-256 ranks, then restore source order."""
    if sample_size < 0:
        raise EvaluationError("sample size cannot be negative")
    ranked: list[dict[str, Any]] = []
    for index, chapter in enumerate(chapters):
        if not isinstance(chapter, Mapping):
            raise EvaluationError(f"chapter at index {index} is not a JSON object")
        fingerprint = chapter_fingerprint(chapter)
        rank = hashlib.sha256(f"{per_book_seed}\0{fingerprint}".encode("utf-8")).hexdigest()
        ranked.append(
            {
                "original_chapter_index": index,
                "original_chapter_position": index + 1,
                "chapter_id": _chapter_id(chapter),
                "chapter_number": chapter.get("number"),
                "chapter_title": str(chapter.get("title") or ""),
                "chapter_fingerprint_sha256": fingerprint,
                "selection_rank_sha256": rank,
                "chapter": dict(chapter),
            }
        )

    # Fingerprint and source metadata make hash ties deterministic without depending
    # on candidate iteration order. The index is only a final tie-break for byte-for-
    # byte duplicate chapter objects, which are indistinguishable after reordering.
    ranked.sort(
        key=lambda item: (
            item["selection_rank_sha256"],
            item["chapter_fingerprint_sha256"],
            item["chapter_id"],
            _stable_scalar(item["chapter_number"]),
            item["chapter_title"],
            item["original_chapter_index"],
        )
    )
    selected = ranked[: min(sample_size, len(ranked))]
    for selection_order, item in enumerate(selected, start=1):
        item["selection_order"] = selection_order
    selected.sort(key=lambda item: item["original_chapter_index"])

    expected = min(sample_size, len(chapters))
    selected_indexes = {item["original_chapter_index"] for item in selected}
    if len(selected) != expected or len(selected_indexes) != expected:
        raise EvaluationError("chapter selection did not produce the required unique source indexes")
    return selected


def sample_from_manifest(
    manifest_path: Path,
    run_id: str,
    seed: str,
    output_dir: Path,
    repo_root: Path,
) -> dict[str, Any]:
    """Build sampled package views and their JSON/CSV selection manifests."""
    manifest_path = manifest_path.resolve()
    repo_root = repo_root.resolve()
    output_dir = output_dir.resolve()
    if not run_id.strip():
        raise EvaluationError("run id cannot be empty")
    if not seed:
        raise EvaluationError("sampling seed cannot be empty")
    if not manifest_path.is_file():
        raise EvaluationError(f"package manifest does not exist: {manifest_path}")

    rows = _read_canonical_rows(manifest_path)
    if not rows:
        raise EvaluationError("package manifest contains no canonical scoreable books")

    plans: list[dict[str, Any]] = []
    seen_book_ids: set[str] = set()
    seen_filenames: set[str] = set()
    for row in sorted(rows, key=lambda item: (str(item.get("package_id", "")).casefold(), str(item.get("package_id", "")))):
        book_id = str(row.get("package_id") or "").strip()
        if not book_id:
            raise EvaluationError("canonical manifest row is missing package_id")
        if book_id in seen_book_ids:
            raise EvaluationError(f"duplicate canonical package_id in manifest: {book_id}")
        seen_book_ids.add(book_id)

        source_display = str(row.get("source_path") or "").strip()
        if not source_display:
            raise EvaluationError(f"manifest row for {book_id} is missing source_path")
        source_path = Path(source_display)
        if not source_path.is_absolute():
            source_path = repo_root / source_path
        source_path = source_path.resolve()
        if not source_path.is_file():
            raise EvaluationError(f"source package for {book_id} is not a JSON file: {source_path}")

        expected_source_hash = str(row.get("source_hash") or "").strip().lower()
        if not _SHA256_RE.fullmatch(expected_source_hash):
            raise EvaluationError(f"manifest source hash for {book_id} is not a lowercase SHA-256 digest")
        actual_source_hash = sha256_file(source_path)
        if actual_source_hash != expected_source_hash:
            raise EvaluationError(
                f"source hash mismatch for {book_id}: manifest={expected_source_hash} actual={actual_source_hash}"
            )

        try:
            package = json.loads(source_path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise EvaluationError(f"source package for {book_id} is invalid JSON: {exc}") from exc
        if not isinstance(package, dict):
            raise EvaluationError(f"source package for {book_id} must be a JSON object")
        chapters = package.get("chapters")
        if not isinstance(chapters, list):
            raise EvaluationError(f"source package for {book_id} must contain a chapters array")
        declared_count = str(row.get("detected_chapter_count") or "").strip()
        if declared_count:
            try:
                expected_count = int(declared_count)
            except ValueError as exc:
                raise EvaluationError(f"manifest chapter count for {book_id} is not an integer") from exc
            if expected_count != len(chapters):
                raise EvaluationError(
                    f"chapter count mismatch for {book_id}: manifest={expected_count} actual={len(chapters)}"
                )

        per_book_seed = derive_book_seed(seed, actual_source_hash, book_id)
        selected = select_chapters(chapters, per_book_seed)
        selected_manifest = [_public_selection(item) for item in selected]
        sampled_package = dict(package)
        sampled_package["_chapterflowEvaluationSample"] = {
            "run_id": run_id,
            "book_id": book_id,
            "mode": SAMPLE_MODE,
            "public_seed": seed,
            "per_book_seed_sha256": per_book_seed,
            "algorithm": _selection_method(),
            "original_source": {
                "path": source_display,
                "sha256": actual_source_hash,
                "chapter_count": len(chapters),
            },
            "requested_chapter_count": SAMPLE_SIZE,
            "actual_chapter_count": len(selected_manifest),
            "selected_chapters": selected_manifest,
        }
        sampled_package["chapters"] = [item["chapter"] for item in selected]

        file_slug = slugify(book_id)
        filename_key = file_slug.casefold()
        if filename_key in seen_filenames:
            raise EvaluationError(f"sampled filename collision for package_id: {book_id}")
        seen_filenames.add(filename_key)
        sampled_relative = Path("sampled-packages") / f"{file_slug}.sampled.json"
        sampled_path = output_dir / sampled_relative
        if sampled_path.resolve() == source_path:
            raise EvaluationError(f"sample output would overwrite source package for {book_id}")

        plans.append(
            {
                "book_id": book_id,
                "canonical_title": str(row.get("canonical_title") or book_id),
                "source_path": source_display,
                "source_file": source_path,
                "full_source_sha256": actual_source_hash,
                "source_chapter_count": len(chapters),
                "per_book_seed_sha256": per_book_seed,
                "selected": selected,
                "selected_manifest": selected_manifest,
                "sampled_package": sampled_package,
                "sampled_package_path": sampled_relative.as_posix(),
                "sampled_file": sampled_path,
            }
        )

    books: list[dict[str, Any]] = []
    csv_rows: list[dict[str, Any]] = []
    for plan in plans:
        atomic_write_json(plan["sampled_file"], plan["sampled_package"])
        sampled_hash = sha256_file(plan["sampled_file"])
        selected_manifest = plan["selected_manifest"]
        book_record = {
            "book_id": plan["book_id"],
            "canonical_title": plan["canonical_title"],
            "source_path": plan["source_path"],
            "sampled_package_path": plan["sampled_package_path"],
            "full_source_sha256": plan["full_source_sha256"],
            "sampled_package_sha256": sampled_hash,
            "source_chapter_count": plan["source_chapter_count"],
            "selected_chapter_count": len(selected_manifest),
            "per_book_seed_sha256": plan["per_book_seed_sha256"],
            "selected_chapters": selected_manifest,
        }
        books.append(book_record)
        for selection in selected_manifest:
            csv_rows.append(
                {
                    "run_id": run_id,
                    "sample_mode": SAMPLE_MODE,
                    "sampling_seed": seed,
                    **{key: book_record[key] for key in (
                        "book_id",
                        "canonical_title",
                        "source_path",
                        "sampled_package_path",
                        "full_source_sha256",
                        "sampled_package_sha256",
                        "source_chapter_count",
                        "selected_chapter_count",
                        "per_book_seed_sha256",
                    )},
                    **selection,
                }
            )

    result = {
        "schema_version": SAMPLE_SCHEMA_VERSION,
        "run_id": run_id,
        "sample_mode": SAMPLE_MODE,
        "sampling_seed": seed,
        "scope_limitation": "Experimental chapter sample; results are not a full-book audit.",
        "selection_method": _selection_method(),
        "book_count": len(books),
        "source_chapter_count": sum(int(book["source_chapter_count"]) for book in books),
        "selected_chapter_count": sum(int(book["selected_chapter_count"]) for book in books),
        "books": books,
    }
    write_csv(output_dir / "chapter-sample-manifest.csv", SELECTION_CSV_FIELDS, csv_rows)
    atomic_write_json(output_dir / "chapter-sample-manifest.json", result)
    return result


def _read_canonical_rows(manifest_path: Path) -> list[dict[str, str]]:
    try:
        with manifest_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames or "package_id" not in reader.fieldnames or "source_path" not in reader.fieldnames:
                raise EvaluationError("package manifest must contain package_id and source_path columns")
            rows = []
            for row_number, row in enumerate(reader, start=2):
                if _manifest_flag(row.get("canonical"), default=True, field="canonical", row_number=row_number) and _manifest_flag(
                    row.get("scoreable"), default=True, field="scoreable", row_number=row_number
                ):
                    rows.append(dict(row))
            return rows
    except csv.Error as exc:
        raise EvaluationError(f"package manifest is invalid CSV: {exc}") from exc


def _manifest_flag(value: str | None, *, default: bool, field: str, row_number: int) -> bool:
    if value is None or not value.strip():
        return default
    normalized = value.strip().casefold()
    if normalized in _TRUE:
        return True
    if normalized in _FALSE:
        return False
    raise EvaluationError(f"manifest {field} value on row {row_number} is not boolean: {value!r}")


def _chapter_id(chapter: Mapping[str, Any]) -> str:
    value = chapter.get("chapterId")
    if value in (None, ""):
        value = chapter.get("id")
    return str(value or "")


def _stable_scalar(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _public_selection(item: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: item[key]
        for key in (
            "original_chapter_index",
            "original_chapter_position",
            "selection_order",
            "chapter_id",
            "chapter_number",
            "chapter_title",
            "chapter_fingerprint_sha256",
            "selection_rank_sha256",
        )
    }


def _selection_method() -> dict[str, Any]:
    return {
        "name": "sha256-lowest-rank-v1",
        "sample_size_per_book": SAMPLE_SIZE,
        "per_book_seed": "sha256(utf8(seed + NUL + full_source_sha256 + NUL + book_id))",
        "chapter_fingerprint": "sha256(canonical JSON of the complete chapter object)",
        "chapter_rank": "sha256(utf8(per_book_seed_sha256 + NUL + chapter_fingerprint_sha256))",
        "selection": "Choose the four lowest chapter ranks, or all chapters when fewer than four.",
        "sampled_view_order": "Original source chapter order.",
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True, help="Canonical package-manifest.csv")
    parser.add_argument("--run-id", required=True, help="Evaluation run identifier recorded in both manifests")
    parser.add_argument("--seed", required=True, help="Explicit reproducibility seed")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for manifests and sampled package views")
    parser.add_argument("--repo-root", type=Path, default=Path.cwd(), help="Base for relative source_path values")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        result = sample_from_manifest(args.manifest, args.run_id, args.seed, args.output_dir, args.repo_root)
    except (EvaluationError, OSError, UnicodeError) as exc:
        print(f"sampling error: {exc}", file=sys.stderr)
        return 2
    print(
        json.dumps(
            {
                "book_count": result["book_count"],
                "run_id": result["run_id"],
                "selected_chapter_count": result["selected_chapter_count"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
