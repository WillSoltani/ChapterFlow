#!/usr/bin/env python3
"""Replace discovered full-book jobs with deterministic chapter-sample jobs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any, Mapping, Sequence

from common import (
    EvaluationError,
    atomic_write_json,
    evaluation_scope_from_sample_metadata,
    sha256_file,
    write_csv,
)


PROTOCOL_VERSION = "1.0.0"
EVALUATION_MODE = "chapter_sample"
SAMPLE_MODE = "deterministic-four-chapter-sample"
INFERENCE_SCOPE = "selected_chapters_only"
SCORE_LABEL = "Experimental four-chapter sample score"
SELECTION_ALGORITHM = "sha256-lowest-rank-v1"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_WORD_RE = re.compile(r"\b\w+(?:[\N{RIGHT SINGLE QUOTATION MARK}'-]\w+)*\b", re.UNICODE)

JOB_FIELDS = (
    "job_id",
    "run_id",
    "evaluation_mode",
    "book_id",
    "rater_role",
    "package_path",
    "source_hash",
    "sampled_package_sha256",
    "original_source_sha256",
    "selection_manifest_sha256",
    "sample_protocol_version",
    "sample_mode",
    "inference_scope",
    "score_label",
    "sampling_seed",
    "per_book_seed_sha256",
    "selection_algorithm",
    "source_chapter_count",
    "requested_chapter_count",
    "selected_chapter_count",
    "selected_chapter_indexes",
    "selected_chapter_ids",
    "selected_chapter_titles",
    "selected_chapters_json",
    "evaluation_scope_path",
    "evaluation_scope_sha256",
    "scope_limitation",
    "full_book_certification_eligible",
    "rubric_path",
    "sample_protocol_path",
    "prompt_path",
    "schema_path",
    "output_path",
)

QUEUE_FIELDS = ("queue_rank", "sampled_word_count", *JOB_FIELDS)

RATER_RESULT_FIELDS = (
    "job_id",
    "run_id",
    "evaluation_mode",
    "book_id",
    "rater_role",
    "status",
    "output_path",
    "source_hash",
    "original_source_sha256",
    "selection_manifest_sha256",
    "evaluation_scope_sha256",
    "selected_chapter_count",
    "overall_score",
    "certification_status",
    "chapter_count_read",
    "sha256",
    "error",
)

ADJUDICATION_JOB_FIELDS = (
    "job_id",
    "run_id",
    "evaluation_mode",
    "book_id",
    "package_path",
    "source_hash",
    "sampled_package_sha256",
    "original_source_sha256",
    "selection_manifest_sha256",
    "sample_protocol_version",
    "sample_mode",
    "inference_scope",
    "score_label",
    "sampling_seed",
    "per_book_seed_sha256",
    "selection_algorithm",
    "source_chapter_count",
    "requested_chapter_count",
    "selected_chapter_count",
    "selected_chapters_json",
    "evaluation_scope_path",
    "evaluation_scope_sha256",
    "scope_limitation",
    "full_book_certification_eligible",
    "primary_path",
    "verification_path",
    "rubric_path",
    "sample_protocol_path",
    "prompt_path",
    "schema_path",
    "output_path",
)

ADJUDICATION_RESULT_FIELDS = (
    "job_id",
    "run_id",
    "evaluation_mode",
    "book_id",
    "status",
    "output_path",
    "source_hash",
    "original_source_sha256",
    "selection_manifest_sha256",
    "evaluation_scope_sha256",
    "selected_chapter_count",
    "overall_score",
    "certification_status",
    "confidence",
    "sha256",
    "error",
)

_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}


def prepare_sample_jobs(
    run_dir: Path,
    sample_manifest_path: Path,
    rater_schema_path: Path,
    adjudicated_schema_path: Path,
    *,
    repo_root: Path | None = None,
) -> dict[str, Any]:
    """Validate a sampled catalog and atomically prepare its worker ledgers."""
    run_dir = run_dir.resolve()
    sample_manifest_path = sample_manifest_path.resolve()
    rater_schema_path = _require_sample_schema(rater_schema_path, "blind-rater")
    adjudicated_schema_path = _require_sample_schema(adjudicated_schema_path, "adjudicated")
    if not run_dir.is_dir():
        raise EvaluationError(f"discovered run directory does not exist: {run_dir}")

    package_manifest_path = run_dir / "data" / "package-manifest.csv"
    run_manifest_path = run_dir / "data" / "run-manifest.json"
    if not package_manifest_path.is_file() or not run_manifest_path.is_file():
        raise EvaluationError("sample jobs require an already-discovered run with package and run manifests")
    if not sample_manifest_path.is_file():
        raise EvaluationError(f"chapter-sample manifest does not exist: {sample_manifest_path}")
    sample_csv_path = sample_manifest_path.with_suffix(".csv")
    if not sample_csv_path.is_file():
        raise EvaluationError(f"chapter-sample CSV manifest does not exist: {sample_csv_path}")

    run_manifest = _read_json_object(run_manifest_path, "run manifest")
    run_id = str(run_manifest.get("run_id") or "").strip()
    if not run_id or run_id != run_dir.name:
        raise EvaluationError(f"run id must equal the run directory name: {run_id!r} != {run_dir.name!r}")
    if repo_root is None:
        declared_root = str(run_manifest.get("repository_root") or "").strip()
        repo_root = Path(declared_root) if declared_root else run_dir.parents[2]
    repo_root = repo_root.resolve()

    _assert_unstarted_run(run_dir, run_manifest)
    canonical_rows = _read_canonical_rows(package_manifest_path)
    if not canonical_rows:
        raise EvaluationError("discovered package manifest contains no canonical scoreable books")
    canonical_by_id = {row["package_id"]: row for row in canonical_rows}
    if len(canonical_by_id) != len(canonical_rows):
        raise EvaluationError("discovered package manifest contains duplicate canonical package ids")

    manifest_bytes = sample_manifest_path.read_bytes()
    try:
        sample_manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise EvaluationError(f"chapter-sample manifest is invalid JSON: {exc}") from exc
    if not isinstance(sample_manifest, dict):
        raise EvaluationError("chapter-sample manifest must contain a JSON object")
    _validate_manifest_header(sample_manifest, run_id)
    selection_manifest_sha256 = hashlib.sha256(manifest_bytes).hexdigest()

    books_value = sample_manifest.get("books")
    if not isinstance(books_value, list):
        raise EvaluationError("chapter-sample manifest books must be an array")
    sample_by_id: dict[str, Mapping[str, Any]] = {}
    for item in books_value:
        if not isinstance(item, Mapping):
            raise EvaluationError("every chapter-sample manifest book must be an object")
        book_id = str(item.get("book_id") or "").strip()
        if not book_id:
            raise EvaluationError("chapter-sample manifest book is missing book_id")
        if book_id in sample_by_id:
            raise EvaluationError(f"duplicate sampled book id: {book_id}")
        sample_by_id[book_id] = item
    canonical_ids = set(canonical_by_id)
    sample_ids = set(sample_by_id)
    if canonical_ids != sample_ids:
        missing = sorted(canonical_ids - sample_ids)
        extra = sorted(sample_ids - canonical_ids)
        raise EvaluationError(f"sampled/canonical book sets differ: missing={missing} extra={extra}")
    if _as_int(sample_manifest.get("book_count"), "sample book_count") != len(canonical_rows):
        raise EvaluationError("sample book_count does not equal the canonical discovered book count")
    if int(run_manifest.get("canonical_books") or 0) != len(canonical_rows):
        raise EvaluationError("run manifest canonical_books does not match package-manifest.csv")

    skill_root = Path(__file__).resolve().parents[1]
    rubric_path = _require_file(skill_root / "references" / "rubric-v2.md", "rubric")
    sample_protocol_path = _require_file(
        skill_root / "references" / "chapter-sample-protocol.md", "sample protocol"
    )
    rater_prompt_path = _require_file(
        skill_root / "references" / "book-rater-sample-prompt.md", "sample rater prompt"
    )
    adjudication_prompt_path = _require_file(
        skill_root / "references" / "adjudication-sample-prompt.md", "sample adjudication prompt"
    )

    sampling_seed = str(sample_manifest.get("sampling_seed") or "")
    scope_limitation = str(sample_manifest.get("scope_limitation") or "").strip()
    selection_method = sample_manifest.get("selection_method")
    if not isinstance(selection_method, Mapping):
        raise EvaluationError("sample selection_method must be an object")
    selection_algorithm_json = _compact_json(selection_method)

    plans: list[dict[str, Any]] = []
    population_chapter_count = 0
    selected_chapter_count = 0
    sampled_word_count = 0
    for book_id in sorted(canonical_by_id, key=lambda value: (value.casefold(), value)):
        discovered = canonical_by_id[book_id]
        sampled = sample_by_id[book_id]
        plan = _validate_sampled_book(
            run_dir=run_dir,
            manifest_origin=sample_manifest_path.parent,
            repo_root=repo_root,
            run_id=run_id,
            sampling_seed=sampling_seed,
            selection_method=selection_method,
            selection_manifest_sha256=selection_manifest_sha256,
            scope_limitation=scope_limitation,
            discovered=discovered,
            sampled=sampled,
        )
        plans.append(plan)
        population_chapter_count += plan["source_chapter_count"]
        selected_chapter_count += plan["selected_chapter_count"]
        sampled_word_count += plan["sampled_word_count"]

    if _as_int(sample_manifest.get("source_chapter_count"), "sample source_chapter_count") != population_chapter_count:
        raise EvaluationError("sample source_chapter_count does not match its per-book records")
    if _as_int(sample_manifest.get("selected_chapter_count"), "sample selected_chapter_count") != selected_chapter_count:
        raise EvaluationError("sample selected_chapter_count does not match its per-book records")
    _validate_selection_csv(sample_csv_path, plans)

    jobs: list[dict[str, Any]] = []
    adjudication_jobs: list[dict[str, Any]] = []
    output_paths: set[str] = set()
    for plan in sorted(plans, key=lambda item: (item["canonical_title"].casefold(), item["book_id"])):
        plan_book_id = str(plan["book_id"])
        common = {
            "run_id": run_id,
            "evaluation_mode": EVALUATION_MODE,
            "book_id": plan["book_id"],
            "package_path": str(plan["sampled_package_path"]),
            "source_hash": plan["sampled_package_sha256"],
            "sampled_package_sha256": plan["sampled_package_sha256"],
            "original_source_sha256": plan["original_source_sha256"],
            "selection_manifest_sha256": selection_manifest_sha256,
            "sample_protocol_version": PROTOCOL_VERSION,
            "sample_mode": SAMPLE_MODE,
            "inference_scope": INFERENCE_SCOPE,
            "score_label": SCORE_LABEL,
            "sampling_seed": sampling_seed,
            "per_book_seed_sha256": plan["per_book_seed_sha256"],
            "selection_algorithm": selection_algorithm_json,
            "source_chapter_count": plan["source_chapter_count"],
            "requested_chapter_count": plan["requested_chapter_count"],
            "selected_chapter_count": plan["selected_chapter_count"],
            "selected_chapter_indexes": _compact_json(plan["selected_chapter_indexes"]),
            "selected_chapter_ids": _compact_json(plan["selected_chapter_ids"]),
            "selected_chapter_titles": _compact_json(plan["selected_chapter_titles"]),
            "selected_chapters_json": _compact_json(plan["selected_chapters"]),
            "evaluation_scope_path": str(plan["evaluation_scope_path"]),
            "evaluation_scope_sha256": plan["evaluation_scope_sha256"],
            "scope_limitation": scope_limitation,
            "full_book_certification_eligible": False,
            "rubric_path": str(rubric_path),
            "sample_protocol_path": str(sample_protocol_path),
        }
        role_outputs: dict[str, str] = {}
        for role in ("primary", "verification"):
            output_path = run_dir / "raw" / "sample" / role / f"{plan_book_id}.json"
            output_text = str(output_path)
            if output_text in output_paths:
                raise EvaluationError(f"duplicate sample result output path: {output_path}")
            output_paths.add(output_text)
            role_outputs[role] = output_text
            jobs.append(
                {
                    **common,
                    "job_id": f"{plan_book_id}--chapter-sample--{role}",
                    "rater_role": role,
                    "prompt_path": str(rater_prompt_path),
                    "schema_path": str(rater_schema_path),
                    "output_path": output_text,
                    "sampled_word_count": plan["sampled_word_count"],
                    "canonical_title": plan["canonical_title"],
                }
            )

        adjudicated_output = run_dir / "raw" / "sample" / "adjudicated" / f"{plan_book_id}.json"
        if str(adjudicated_output) in output_paths:
            raise EvaluationError(f"duplicate adjudicated sample output path: {adjudicated_output}")
        output_paths.add(str(adjudicated_output))
        adjudication_jobs.append(
            {
                **{key: common[key] for key in ADJUDICATION_JOB_FIELDS if key in common},
                "job_id": f"{plan_book_id}--chapter-sample--adjudication",
                "primary_path": role_outputs["primary"],
                "verification_path": role_outputs["verification"],
                "prompt_path": str(adjudication_prompt_path),
                "schema_path": str(adjudicated_schema_path),
                "output_path": str(adjudicated_output),
            }
        )

    expected_jobs = len(canonical_rows) * 2
    if len(jobs) != expected_jobs:
        raise EvaluationError(f"sample job count mismatch: expected {expected_jobs}, got {len(jobs)}")
    _assert_same_sample_for_both_roles(jobs)

    queue = sorted(
        jobs,
        key=lambda row: (
            -int(row["sampled_word_count"]),
            str(row["canonical_title"]).casefold(),
            str(row["book_id"]),
            0 if row["rater_role"] == "primary" else 1,
        ),
    )
    queue_rows = [{"queue_rank": rank, **row} for rank, row in enumerate(queue, start=1)]

    target_json = run_dir / "data" / "chapter-sample-manifest.json"
    target_csv = run_dir / "data" / "chapter-sample-manifest.csv"
    _atomic_write_bytes(target_json, manifest_bytes)
    _atomic_write_bytes(target_csv, sample_csv_path.read_bytes())
    if sha256_file(target_json) != selection_manifest_sha256:
        raise EvaluationError("copied chapter-sample manifest hash changed unexpectedly")

    for plan in plans:
        _atomic_write_bytes(plan["evaluation_scope_path"], plan["evaluation_scope_bytes"])
        if sha256_file(plan["evaluation_scope_path"]) != plan["evaluation_scope_sha256"]:
            raise EvaluationError(f"copied evaluation scope hash changed for {plan['book_id']}")

    for relative in ("raw/sample/primary", "raw/sample/verification", "raw/sample/adjudicated", "jobs"):
        (run_dir / relative).mkdir(parents=True, exist_ok=True)
    write_csv(run_dir / "jobs" / "book-rater-jobs.csv", JOB_FIELDS, jobs)
    write_csv(run_dir / "jobs" / "book-rater-queue.csv", QUEUE_FIELDS, queue_rows)
    write_csv(run_dir / "jobs" / "book-rater-results.csv", RATER_RESULT_FIELDS, [])
    write_csv(run_dir / "jobs" / "adjudication-jobs.csv", ADJUDICATION_JOB_FIELDS, adjudication_jobs)
    write_csv(run_dir / "jobs" / "adjudication-results.csv", ADJUDICATION_RESULT_FIELDS, [])

    run_manifest["evaluation_mode"] = EVALUATION_MODE
    run_manifest["status"] = "sample-jobs-ready"
    run_manifest["sampling"] = {
        "mode": EVALUATION_MODE,
        "protocol_version": PROTOCOL_VERSION,
        "sample_mode": SAMPLE_MODE,
        "score_scope": INFERENCE_SCOPE,
        "result_interpretation": "exploratory_sample_estimate",
        "score_label": SCORE_LABEL,
        "requested_chapters_per_book": 4,
        "sampling_seed": sampling_seed,
        "selection_algorithm": SELECTION_ALGORITHM,
        "selection_manifest_json": "data/chapter-sample-manifest.json",
        "selection_manifest_csv": "data/chapter-sample-manifest.csv",
        "selection_manifest_sha256": selection_manifest_sha256,
        "population_chapter_count": population_chapter_count,
        "selected_chapter_count": selected_chapter_count,
        "not_sampled_chapter_count": population_chapter_count - selected_chapter_count,
        "blind_chapter_reads": selected_chapter_count * 2,
        "population_coverage_ratio": selected_chapter_count / population_chapter_count,
        "full_book_certification_eligible": False,
        "scope_limitation": scope_limitation,
    }
    limitations = run_manifest.get("limitations")
    if not isinstance(limitations, list):
        limitations = []
    for limitation in (
        scope_limitation,
        "Unsampled content may materially change every score, rank, gate, and recommendation.",
    ):
        if limitation and limitation not in limitations:
            limitations.append(limitation)
    run_manifest["limitations"] = limitations
    validation = run_manifest.get("validation")
    if not isinstance(validation, dict):
        validation = {}
    validation["book_results"] = "pending (experimental chapter sample)"
    run_manifest["validation"] = validation
    atomic_write_json(run_manifest_path, run_manifest)

    return {
        "run_id": run_id,
        "evaluation_mode": EVALUATION_MODE,
        "canonical_books": len(canonical_rows),
        "blind_jobs": len(jobs),
        "adjudication_jobs": len(adjudication_jobs),
        "population_chapter_count": population_chapter_count,
        "selected_chapter_count": selected_chapter_count,
        "blind_chapter_reads": selected_chapter_count * 2,
        "sampled_word_count": sampled_word_count,
        "selection_manifest_sha256": selection_manifest_sha256,
    }


def _validate_manifest_header(manifest: Mapping[str, Any], run_id: str) -> None:
    expected = {
        "schema_version": PROTOCOL_VERSION,
        "run_id": run_id,
        "sample_mode": SAMPLE_MODE,
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            raise EvaluationError(f"sample manifest {key} mismatch: expected {value!r}, got {manifest.get(key)!r}")
    seed = manifest.get("sampling_seed")
    if not isinstance(seed, str) or not seed:
        raise EvaluationError("sample manifest sampling_seed must be a non-empty string")
    limitation = manifest.get("scope_limitation")
    if not isinstance(limitation, str) or not limitation.strip():
        raise EvaluationError("sample manifest scope_limitation must be non-empty")
    method = manifest.get("selection_method")
    if not isinstance(method, Mapping) or method.get("name") != SELECTION_ALGORITHM:
        raise EvaluationError(f"sample selection algorithm must be {SELECTION_ALGORITHM}")
    if _as_int(method.get("sample_size_per_book"), "selection sample_size_per_book") != 4:
        raise EvaluationError("sample selection method must request four chapters per book")


def _validate_sampled_book(
    *,
    run_dir: Path,
    manifest_origin: Path,
    repo_root: Path,
    run_id: str,
    sampling_seed: str,
    selection_method: Mapping[str, Any],
    selection_manifest_sha256: str,
    scope_limitation: str,
    discovered: Mapping[str, str],
    sampled: Mapping[str, Any],
) -> dict[str, Any]:
    book_id = discovered["package_id"]
    original_hash = _sha256(sampled.get("full_source_sha256"), f"full source hash for {book_id}")
    if original_hash != str(discovered.get("source_hash") or ""):
        raise EvaluationError(f"original source hash mismatch for sampled book {book_id}")
    source_chapter_count = _as_int(sampled.get("source_chapter_count"), f"source chapter count for {book_id}")
    if source_chapter_count != _as_int(discovered.get("detected_chapter_count"), f"discovered count for {book_id}"):
        raise EvaluationError(f"source chapter count mismatch for sampled book {book_id}")
    selected_count = _as_int(sampled.get("selected_chapter_count"), f"selected chapter count for {book_id}")
    expected_selected = min(4, source_chapter_count)
    if selected_count != expected_selected:
        raise EvaluationError(
            f"selected chapter count for {book_id} must be min(4, source count)={expected_selected}, got {selected_count}"
        )
    selected = sampled.get("selected_chapters")
    if not isinstance(selected, list) or len(selected) != selected_count:
        raise EvaluationError(f"selected_chapters for {book_id} must contain exactly {selected_count} records")
    _validate_selected_chapters(book_id, selected, source_chapter_count)

    sampled_hash = _sha256(sampled.get("sampled_package_sha256"), f"sampled package hash for {book_id}")
    sampled_path = _resolve_sample_path(
        str(sampled.get("sampled_package_path") or ""),
        expected_hash=sampled_hash,
        run_dir=run_dir,
        manifest_origin=manifest_origin,
    )
    source_display = str(discovered.get("source_path") or "")
    original_path = Path(source_display)
    if not original_path.is_absolute():
        original_path = repo_root / original_path
    if sampled_path == original_path.resolve():
        raise EvaluationError(f"sample job for {book_id} resolves to the original full package")

    sampled_package = _read_json_object(sampled_path, f"sampled package for {book_id}")
    chapters = sampled_package.get("chapters")
    if not isinstance(chapters, list) or len(chapters) != selected_count:
        raise EvaluationError(f"sampled package for {book_id} must contain exactly {selected_count} chapters")
    scope = sampled_package.get("_chapterflowEvaluationSample")
    if not isinstance(scope, Mapping):
        raise EvaluationError(f"sampled package for {book_id} lacks _chapterflowEvaluationSample metadata")
    exact_scope = {
        "run_id": run_id,
        "book_id": book_id,
        "mode": SAMPLE_MODE,
        "public_seed": sampling_seed,
        "per_book_seed_sha256": sampled.get("per_book_seed_sha256"),
        "algorithm": selection_method,
        "requested_chapter_count": 4,
        "actual_chapter_count": selected_count,
        "selected_chapters": selected,
    }
    for key, value in exact_scope.items():
        if scope.get(key) != value:
            raise EvaluationError(f"sample package metadata {key} mismatch for {book_id}")
    original_scope = scope.get("original_source")
    if not isinstance(original_scope, Mapping):
        raise EvaluationError(f"sample package original_source metadata is missing for {book_id}")
    if original_scope.get("sha256") != original_hash or original_scope.get("chapter_count") != source_chapter_count:
        raise EvaluationError(f"sample package original source identity mismatch for {book_id}")
    if str(original_scope.get("path") or "") != str(sampled.get("source_path") or ""):
        raise EvaluationError(f"sample package original source path mismatch for {book_id}")
    if str(sampled.get("source_path") or "") != source_display:
        raise EvaluationError(f"sample manifest source path mismatch for {book_id}")

    for chapter, selection in zip(chapters, selected, strict=True):
        if not isinstance(chapter, Mapping):
            raise EvaluationError(f"sampled chapter for {book_id} is not an object")
        chapter_id = chapter.get("chapterId") if chapter.get("chapterId") not in (None, "") else chapter.get("id")
        if str(chapter_id or "") != str(selection.get("chapter_id") or ""):
            raise EvaluationError(f"sampled chapter id does not match selection metadata for {book_id}")
        if str(chapter.get("title") or "") != str(selection.get("chapter_title") or ""):
            raise EvaluationError(f"sampled chapter title does not match selection metadata for {book_id}")

    per_book_seed = _sha256(sampled.get("per_book_seed_sha256"), f"per-book seed for {book_id}")
    evaluation_scope = evaluation_scope_from_sample_metadata(
        scope,
        sampled_package_sha256=sampled_hash,
        selection_manifest_sha256=selection_manifest_sha256,
        scope_limitation=scope_limitation,
    )
    evaluation_scope_bytes = (
        json.dumps(evaluation_scope, ensure_ascii=False, indent=2, sort_keys=False) + "\n"
    ).encode("utf-8")
    evaluation_scope_path = run_dir / "jobs" / "evaluation-scopes" / f"{book_id}.json"
    return {
        "book_id": book_id,
        "canonical_title": str(discovered.get("canonical_title") or book_id),
        "sampled_package_path": sampled_path,
        "sampled_package_sha256": sampled_hash,
        "original_source_sha256": original_hash,
        "source_chapter_count": source_chapter_count,
        "requested_chapter_count": 4,
        "selected_chapter_count": selected_count,
        "per_book_seed_sha256": per_book_seed,
        "selected_chapters": selected,
        "selected_chapter_indexes": [item["original_chapter_index"] for item in selected],
        "selected_chapter_ids": [item["chapter_id"] for item in selected],
        "selected_chapter_titles": [item["chapter_title"] for item in selected],
        "sampled_word_count": _count_words(chapters),
        "evaluation_scope_path": evaluation_scope_path,
        "evaluation_scope_bytes": evaluation_scope_bytes,
        "evaluation_scope_sha256": hashlib.sha256(evaluation_scope_bytes).hexdigest(),
    }


def _validate_selected_chapters(book_id: str, selected: Sequence[Any], source_count: int) -> None:
    required = {
        "original_chapter_index",
        "original_chapter_position",
        "selection_order",
        "chapter_id",
        "chapter_number",
        "chapter_title",
        "chapter_fingerprint_sha256",
        "selection_rank_sha256",
    }
    indexes: list[int] = []
    orders: list[int] = []
    for item in selected:
        if not isinstance(item, Mapping) or not required.issubset(item):
            raise EvaluationError(f"selected chapter metadata is incomplete for {book_id}")
        index = _as_int(item["original_chapter_index"], f"original chapter index for {book_id}")
        position = _as_int(item["original_chapter_position"], f"original chapter position for {book_id}")
        order = _as_int(item["selection_order"], f"selection order for {book_id}")
        if index < 0 or index >= source_count or position != index + 1:
            raise EvaluationError(f"selected chapter index/position is invalid for {book_id}")
        _sha256(item["chapter_fingerprint_sha256"], f"chapter fingerprint for {book_id}")
        _sha256(item["selection_rank_sha256"], f"chapter rank for {book_id}")
        indexes.append(index)
        orders.append(order)
    if indexes != sorted(indexes) or len(set(indexes)) != len(indexes):
        raise EvaluationError(f"selected chapters for {book_id} must be unique and in original source order")
    if sorted(orders) != list(range(1, len(selected) + 1)):
        raise EvaluationError(f"selection orders for {book_id} must be the integers 1..{len(selected)}")


def _resolve_sample_path(
    display: str,
    *,
    expected_hash: str,
    run_dir: Path,
    manifest_origin: Path,
) -> Path:
    if not display.strip():
        raise EvaluationError("sampled_package_path cannot be empty")
    supplied = Path(display)
    candidates = [supplied] if supplied.is_absolute() else [
        manifest_origin / supplied,
        run_dir / supplied,
        run_dir / "tmp" / supplied,
        run_dir / "data" / supplied,
    ]
    resolved: list[Path] = []
    for candidate in candidates:
        value = candidate.resolve()
        if value not in resolved and value.is_file() and sha256_file(value) == expected_hash:
            resolved.append(value)
    if not resolved:
        raise EvaluationError(f"cannot resolve sampled package with declared hash: {display}")
    if len(resolved) > 1:
        raise EvaluationError(f"sampled package path is ambiguous across run locations: {display}")
    path = resolved[0]
    try:
        path.relative_to(run_dir)
    except ValueError as exc:
        raise EvaluationError(f"sampled package must be contained inside the run directory: {path}") from exc
    return path


def _validate_selection_csv(path: Path, plans: Sequence[Mapping[str, Any]]) -> None:
    expected = {
        (str(plan["book_id"]), int(item["original_chapter_index"]))
        for plan in plans
        for item in plan["selected_chapters"]
    }
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not {"book_id", "original_chapter_index"}.issubset(reader.fieldnames):
            raise EvaluationError("chapter-sample CSV must include book_id and original_chapter_index")
        actual: list[tuple[str, int]] = []
        try:
            for row in reader:
                actual.append((str(row.get("book_id") or ""), int(str(row.get("original_chapter_index") or ""))))
        except (csv.Error, ValueError) as exc:
            raise EvaluationError(f"chapter-sample CSV is invalid: {exc}") from exc
    if len(actual) != len(expected) or set(actual) != expected:
        raise EvaluationError("chapter-sample JSON and CSV selection records differ")


def _read_canonical_rows(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            required = {"package_id", "source_path", "source_hash", "detected_chapter_count"}
            if not reader.fieldnames or not required.issubset(reader.fieldnames):
                raise EvaluationError("package manifest is missing required discovery fields")
            rows = []
            for row_number, row in enumerate(reader, start=2):
                if _csv_flag(row.get("canonical"), True, "canonical", row_number) and _csv_flag(
                    row.get("scoreable"), True, "scoreable", row_number
                ):
                    rows.append(dict(row))
            return rows
    except csv.Error as exc:
        raise EvaluationError(f"package manifest is invalid CSV: {exc}") from exc


def _csv_flag(value: str | None, default: bool, field: str, row_number: int) -> bool:
    if value is None or not value.strip():
        return default
    normalized = value.strip().casefold()
    if normalized in _TRUE:
        return True
    if normalized in _FALSE:
        return False
    raise EvaluationError(f"package manifest {field} on row {row_number} is not boolean")


def _assert_unstarted_run(run_dir: Path, run_manifest: Mapping[str, Any]) -> None:
    results_path = run_dir / "jobs" / "book-rater-results.csv"
    if results_path.is_file():
        with results_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle)
            next(reader, None)
            if any(any(cell.strip() for cell in row) for row in reader):
                raise EvaluationError("cannot replace jobs after a rater result has been recorded; use a fresh discovered run")
    for relative in ("raw/primary", "raw/verification", "raw/adjudicated", "raw/sample"):
        root = run_dir / relative
        if root.exists() and any(path.is_file() and path.suffix.lower() == ".json" for path in root.rglob("*.json")):
            raise EvaluationError(f"cannot replace jobs after result JSON exists under {relative}; use a fresh discovered run")
    mode = run_manifest.get("evaluation_mode")
    if mode not in (None, "", EVALUATION_MODE):
        raise EvaluationError(f"run already declares incompatible evaluation_mode: {mode}")


def _assert_same_sample_for_both_roles(jobs: Sequence[Mapping[str, Any]]) -> None:
    ignored = {"job_id", "rater_role", "output_path", "sampled_word_count", "canonical_title"}
    by_book: dict[str, list[Mapping[str, Any]]] = {}
    for job in jobs:
        by_book.setdefault(str(job["book_id"]), []).append(job)
    for book_id, pair in by_book.items():
        if len(pair) != 2 or {job["rater_role"] for job in pair} != {"primary", "verification"}:
            raise EvaluationError(f"sample book {book_id} does not have exactly one job per blind role")
        first, second = pair
        if any(first.get(key) != second.get(key) for key in JOB_FIELDS if key not in ignored):
            raise EvaluationError(f"blind roles for {book_id} do not share the identical sample identity")


def _require_sample_schema(path: Path, label: str) -> Path:
    path = _require_file(path, f"{label} sample schema")
    value = _read_json_object(path, f"{label} sample schema")
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True)
    if "evaluation_scope" not in encoded or "chapter_sample" not in encoded:
        raise EvaluationError(f"{label} schema is not sample-aware: {path}")
    return path


def _require_file(path: Path, label: str) -> Path:
    path = path.resolve()
    if not path.is_file():
        raise EvaluationError(f"{label} does not exist: {path}")
    return path


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise EvaluationError(f"{label} is invalid JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise EvaluationError(f"{label} must contain a JSON object")
    return value


def _count_words(value: Any) -> int:
    if isinstance(value, str):
        return len(_WORD_RE.findall(value))
    if isinstance(value, Mapping):
        return sum(_count_words(item) for item in value.values())
    if isinstance(value, list):
        return sum(_count_words(item) for item in value)
    return 0


def _sha256(value: Any, label: str) -> str:
    text = str(value or "").strip().lower()
    if not _SHA256_RE.fullmatch(text):
        raise EvaluationError(f"{label} must be a lowercase SHA-256 digest")
    return text


def _as_int(value: Any, label: str) -> int:
    if isinstance(value, bool):
        raise EvaluationError(f"{label} must be an integer")
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise EvaluationError(f"{label} must be an integer") from exc
    if result < 0:
        raise EvaluationError(f"{label} cannot be negative")
    return result


def _compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _atomic_write_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file() and path.read_bytes() == value:
        return
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True, help="Already-discovered evaluation run")
    parser.add_argument(
        "--sample-manifest", type=Path, required=True, help="chapter-sample-manifest.json produced by sample_chapters.py"
    )
    parser.add_argument("--rater-schema", type=Path, required=True, help="Sample-aware blind evaluation schema")
    parser.add_argument("--adjudicated-schema", type=Path, required=True, help="Sample-aware adjudicated schema")
    parser.add_argument("--repo-root", type=Path, help="Repository root; defaults to run-manifest.json")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        summary = prepare_sample_jobs(
            args.run_dir,
            args.sample_manifest,
            args.rater_schema,
            args.adjudicated_schema,
            repo_root=args.repo_root,
        )
    except (EvaluationError, OSError, UnicodeError) as exc:
        print(f"sample job preparation error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
