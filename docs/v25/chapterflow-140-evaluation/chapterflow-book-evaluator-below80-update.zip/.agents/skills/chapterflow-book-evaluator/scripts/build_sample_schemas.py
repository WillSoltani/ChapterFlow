#!/usr/bin/env python3
"""Build additive JSON Schemas for experimental chapter-sample results."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
from typing import Any, Mapping, MutableMapping

from common import (
    DOMAINS,
    SAMPLE_CERTIFICATION_STATUSES,
    SAMPLE_CLASSIFICATION,
    SAMPLE_EVALUATION_MODE,
    SAMPLE_INFERENCE_SCOPE,
    SAMPLE_PACKAGE_MODE,
    SAMPLE_PROTOCOL_VERSION,
    SAMPLE_REPORT_RESULT_TYPE,
    SAMPLE_RESULT_TYPE,
    SAMPLE_SCORE_LABEL,
    SAMPLE_SELECTION_ALGORITHM,
    atomic_write_json,
)


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
REFERENCES_DIR = SKILL_ROOT / "references"
SCHEMA_FILENAMES = {
    "blind": "book-evaluation-sample.schema.json",
    "adjudicated": "adjudicated-book-sample.schema.json",
    "report": "report-data-sample.schema.json",
}
BASE_FILENAMES = {
    "blind": "book-evaluation.schema.json",
    "adjudicated": "adjudicated-book.schema.json",
    "report": "report-data.schema.json",
}
_SHA256_SCHEMA = {"type": "string", "pattern": "^[0-9a-f]{64}$"}


def _selection_algorithm_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "required": ["name"],
        "properties": {"name": {"const": SAMPLE_SELECTION_ALGORITHM}},
        "additionalProperties": True,
    }


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"schema must be a JSON object: {path}")
    return value


def _sample_selection_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "original_chapter_index",
            "original_chapter_position",
            "selection_order",
            "chapter_id",
            "chapter_number",
            "chapter_title",
            "chapter_fingerprint_sha256",
            "selection_rank_sha256",
        ],
        "properties": {
            "original_chapter_index": {"type": "integer", "minimum": 0},
            "original_chapter_position": {"type": "integer", "minimum": 1},
            "selection_order": {"type": "integer", "minimum": 1},
            "chapter_id": {"type": "string"},
            "chapter_number": {"type": ["integer", "string", "null"]},
            "chapter_title": {"type": "string", "minLength": 1},
            "chapter_fingerprint_sha256": copy.deepcopy(_SHA256_SCHEMA),
            "selection_rank_sha256": copy.deepcopy(_SHA256_SCHEMA),
        },
    }


def _evaluation_scope_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "protocol_version",
            "mode",
            "sample_mode",
            "inference_scope",
            "score_label",
            "public_seed",
            "per_book_seed_sha256",
            "selection_algorithm",
            "selection_manifest_sha256",
            "original_source",
            "sampled_package_sha256",
            "requested_chapter_count",
            "selected_chapter_count",
            "selected_chapters",
            "scope_limitation",
            "full_book_certification_eligible",
        ],
        "properties": {
            "protocol_version": {"const": SAMPLE_PROTOCOL_VERSION},
            "mode": {"const": SAMPLE_EVALUATION_MODE},
            "sample_mode": {"const": SAMPLE_PACKAGE_MODE},
            "inference_scope": {"const": SAMPLE_INFERENCE_SCOPE},
            "score_label": {"const": SAMPLE_SCORE_LABEL},
            "public_seed": {"type": "string", "minLength": 1},
            "per_book_seed_sha256": copy.deepcopy(_SHA256_SCHEMA),
            "selection_algorithm": _selection_algorithm_schema(),
            "selection_manifest_sha256": copy.deepcopy(_SHA256_SCHEMA),
            "original_source": {
                "type": "object",
                "additionalProperties": False,
                "required": ["path", "sha256", "chapter_count"],
                "properties": {
                    "path": {"type": "string", "minLength": 1},
                    "sha256": copy.deepcopy(_SHA256_SCHEMA),
                    "chapter_count": {"type": "integer", "minimum": 0},
                },
            },
            "sampled_package_sha256": copy.deepcopy(_SHA256_SCHEMA),
            "requested_chapter_count": {"type": "integer", "minimum": 1},
            "selected_chapter_count": {"type": "integer", "minimum": 1},
            "selected_chapters": {
                "type": "array",
                "minItems": 1,
                "uniqueItems": True,
                "items": {"$ref": "#/$defs/sampleSelection"},
            },
            "scope_limitation": {"type": "string", "minLength": 1},
            "full_book_certification_eligible": {"const": False},
        },
    }


def _sample_result_properties() -> dict[str, Any]:
    return {
        "result_type": {"const": SAMPLE_RESULT_TYPE},
        "evaluation_scope": {"$ref": "#/$defs/evaluationScope"},
        "sample_scope_acknowledged": {"const": True},
        "unsampled_content_claims_found": {"const": False},
        "scope_limited_subcriteria": {
            "type": "array",
            "minItems": 1,
            "uniqueItems": True,
            "items": {
                "enum": [
                    f"domains.{domain}.subcriteria.{subcriterion}"
                    for domain, definition in DOMAINS.items()
                    for subcriterion in definition["subcriteria"]
                ]
            },
        },
    }


def _restrict_sample_gates(definitions: MutableMapping[str, Any]) -> None:
    gate_refs = {
        "technical_completeness": ["conditional", "fail", "unevaluable", "not_assessed"],
        "epistemic_instructional_safety": ["fail", "not_assessed"],
        "ethics_reader_autonomy": ["fail", "not_assessed"],
        "purpose_audience_declaration": ["not_assessed"],
        "external_accuracy": ["not_assessed"],
    }
    gate_definition = definitions["gates"]
    for gate_key, statuses in gate_refs.items():
        gate_definition["properties"][gate_key] = {
            "allOf": [
                {"$ref": "#/$defs/gate"},
                {
                    "type": "object",
                    "properties": {"status": {"enum": statuses}},
                },
            ]
        }


def _add_sample_chapter_identity(definitions: MutableMapping[str, Any]) -> None:
    chapter = definitions["chapterEvidence"]
    for key in ("original_chapter_index", "original_chapter_position", "selection_order"):
        if key not in chapter["required"]:
            chapter["required"].append(key)
    chapter["properties"].update(
        {
            "original_chapter_index": {"type": "integer", "minimum": 0},
            "original_chapter_position": {"type": "integer", "minimum": 1},
            "selection_order": {"type": "integer", "minimum": 1},
        }
    )


def _apply_shared_result_contract(
    schema: MutableMapping[str, Any],
    result_schema: MutableMapping[str, Any],
) -> None:
    definitions = schema["$defs"]
    definitions["sampleSelection"] = _sample_selection_schema()
    definitions["evaluationScope"] = _evaluation_scope_schema()
    _add_sample_chapter_identity(definitions)
    _restrict_sample_gates(definitions)
    definitions["classification"] = {"const": SAMPLE_CLASSIFICATION}
    definitions["domainBase"]["properties"]["whole_book_pattern"] = {
        "type": "string",
        "pattern": "^Sample-wide pattern:",
    }
    definitions["analysis"]["properties"]["final_verdict"] = {
        "type": "string",
        "pattern": "^Experimental (?:[a-z]+|[0-9]+)-chapter sample:",
    }
    for key in _sample_result_properties():
        if key not in result_schema["required"]:
            result_schema["required"].append(key)
    result_schema["properties"].update(_sample_result_properties())
    result_schema["properties"]["source_hash"] = copy.deepcopy(_SHA256_SCHEMA)
    result_schema["properties"]["certification_status"] = {
        "enum": sorted(SAMPLE_CERTIFICATION_STATUSES)
    }


def build_blind_schema(base: Mapping[str, Any]) -> dict[str, Any]:
    schema = copy.deepcopy(dict(base))
    schema["$id"] = "https://chapterflow.local/schemas/book-evaluation-sample.schema.json"
    schema["title"] = "ChapterFlow Experimental Chapter-Sample Blind Evaluation v2.0"
    _apply_shared_result_contract(schema, schema)
    return schema


def build_adjudicated_schema(base: Mapping[str, Any]) -> dict[str, Any]:
    schema = copy.deepcopy(dict(base))
    schema["$id"] = "https://chapterflow.local/schemas/adjudicated-book-sample.schema.json"
    schema["title"] = "ChapterFlow Experimental Chapter-Sample Adjudicated Evaluation v2.0"
    _apply_shared_result_contract(schema, schema)
    return schema


def _sampling_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "mode",
            "protocol_version",
            "sample_mode",
            "score_scope",
            "result_interpretation",
            "score_label",
            "requested_chapters_per_book",
            "sampling_seed",
            "selection_algorithm",
            "selection_manifest_json",
            "selection_manifest_csv",
            "selection_manifest_sha256",
            "population_chapter_count",
            "selected_chapter_count",
            "not_sampled_chapter_count",
            "blind_chapter_reads",
            "population_coverage_ratio",
            "full_book_certification_eligible",
            "scope_limitation",
        ],
        "properties": {
            "mode": {"const": SAMPLE_EVALUATION_MODE},
            "protocol_version": {"const": SAMPLE_PROTOCOL_VERSION},
            "sample_mode": {"const": SAMPLE_PACKAGE_MODE},
            "score_scope": {"const": SAMPLE_INFERENCE_SCOPE},
            "result_interpretation": {"const": "exploratory_sample_estimate"},
            "score_label": {"const": SAMPLE_SCORE_LABEL},
            "requested_chapters_per_book": {"type": "integer", "minimum": 1},
            "sampling_seed": {"type": "string", "minLength": 1},
            "selection_algorithm": {"const": SAMPLE_SELECTION_ALGORITHM},
            "selection_manifest_json": {"type": "string", "minLength": 1},
            "selection_manifest_csv": {"type": "string", "minLength": 1},
            "selection_manifest_sha256": copy.deepcopy(_SHA256_SCHEMA),
            "population_chapter_count": {"type": "integer", "minimum": 0},
            "selected_chapter_count": {"type": "integer", "minimum": 0},
            "not_sampled_chapter_count": {"type": "integer", "minimum": 0},
            "blind_chapter_reads": {"type": "integer", "minimum": 0},
            "population_coverage_ratio": {"type": "number", "minimum": 0, "maximum": 1},
            "full_book_certification_eligible": {"const": False},
            "scope_limitation": {"type": "string", "minLength": 1},
        },
    }


def build_report_schema(base: Mapping[str, Any]) -> dict[str, Any]:
    schema = copy.deepcopy(dict(base))
    schema["$id"] = "https://chapterflow.local/schemas/report-data-sample.schema.json"
    schema["title"] = "ChapterFlow Experimental Chapter-Sample Report Dataset v2.0"
    schema["required"].append("result_type")
    schema["properties"]["result_type"] = {"const": SAMPLE_REPORT_RESULT_TYPE}
    _apply_shared_result_contract(schema, schema["$defs"]["reportBook"])
    schema["$defs"]["sampling"] = _sampling_schema()
    run = schema["$defs"]["run"]
    for key in ("evaluation_mode", "sampling"):
        if key not in run["required"]:
            run["required"].append(key)
    run["properties"]["evaluation_mode"] = {"const": SAMPLE_EVALUATION_MODE}
    run["properties"]["sampling"] = {"$ref": "#/$defs/sampling"}
    return schema


def build_all(base_dir: Path, output_dir: Path) -> dict[str, dict[str, Any]]:
    bases = {key: _read_json(base_dir / filename) for key, filename in BASE_FILENAMES.items()}
    schemas = {
        "blind": build_blind_schema(bases["blind"]),
        "adjudicated": build_adjudicated_schema(bases["adjudicated"]),
        "report": build_report_schema(bases["report"]),
    }
    for key, schema in schemas.items():
        atomic_write_json(output_dir / SCHEMA_FILENAMES[key], schema)
    return schemas


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dir", type=Path, default=REFERENCES_DIR)
    parser.add_argument("--output-dir", type=Path, default=REFERENCES_DIR)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        build_all(args.base_dir, args.output_dir)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"sample schema build error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(SCHEMA_FILENAMES, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
